/*
Navicat MySQL Data Transfer

Source Server         : 124.222.196.51
Source Server Version : 50709
Source Host           : 124.222.196.51:3306
Source Database       : apolloportaldb

Target Server Type    : MYSQL
Target Server Version : 50709
File Encoding         : 65001

Date: 2022-11-24 21:41:05
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for app
-- ----------------------------
DROP TABLE IF EXISTS `app`;
CREATE TABLE `app` (
  `Id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `AppId` varchar(500) NOT NULL DEFAULT 'default' COMMENT 'AppID',
  `Name` varchar(500) NOT NULL DEFAULT 'default' COMMENT '应用名',
  `OrgId` varchar(32) NOT NULL DEFAULT 'default' COMMENT '部门Id',
  `OrgName` varchar(64) NOT NULL DEFAULT 'default' COMMENT '部门名字',
  `OwnerName` varchar(500) NOT NULL DEFAULT 'default' COMMENT 'ownerName',
  `OwnerEmail` varchar(500) NOT NULL DEFAULT 'default' COMMENT 'ownerEmail',
  `IsDeleted` bit(1) NOT NULL DEFAULT b'0' COMMENT '1: deleted, 0: normal',
  `DataChange_CreatedBy` varchar(32) NOT NULL DEFAULT 'default' COMMENT '创建人邮箱前缀',
  `DataChange_CreatedTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `DataChange_LastModifiedBy` varchar(32) DEFAULT '' COMMENT '最后修改人邮箱前缀',
  `DataChange_LastTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`Id`),
  KEY `AppId` (`AppId`(191)),
  KEY `DataChange_LastTime` (`DataChange_LastTime`),
  KEY `IX_Name` (`Name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COMMENT='应用表';

-- ----------------------------
-- Records of app
-- ----------------------------
INSERT INTO `app` VALUES ('1', 'SampleApp', 'Sample App', 'TEST1', '样例部门1', 'apollo', 'apollo@acme.com', '', 'default', '2022-06-25 18:49:11', 'apollo', '2022-06-25 19:28:56');
INSERT INTO `app` VALUES ('2', 'admin', 'laokou-admin', 'TEST1', '样例部门1', 'apollo', 'apollo@acme.com', '\0', 'apollo', '2022-06-25 18:52:07', 'apollo', '2022-06-25 18:52:07');
INSERT INTO `app` VALUES ('3', 'gateway', 'laokou-gateway', 'TEST1', '样例部门1', 'apollo', 'apollo@acme.com', '\0', 'apollo', '2022-07-02 13:49:10', 'apollo', '2022-07-02 13:49:10');
INSERT INTO `app` VALUES ('4', 'auth', 'laokou-auth', 'TEST1', '样例部门1', 'apollo', 'apollo@acme.com', '', 'apollo', '2022-07-17 12:20:10', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `app` VALUES ('5', 'cas', 'laokou-cas', 'TEST1', '样例部门1', 'apollo', 'apollo@acme.com', '', 'apollo', '2022-09-25 07:24:09', 'apollo', '2022-10-29 16:50:25');
INSERT INTO `app` VALUES ('6', 'elasticsearch', 'laokou-elasticsearch', 'TEST1', '样例部门1', 'apollo', 'apollo@acme.com', '\0', 'apollo', '2022-09-25 07:30:45', 'apollo', '2022-09-25 07:30:45');
INSERT INTO `app` VALUES ('7', 'ump', 'laokou-ump', 'TEST1', '样例部门1', 'apollo', 'apollo@acme.com', '', 'apollo', '2022-10-29 16:48:18', 'apollo', '2022-11-04 18:45:02');
INSERT INTO `app` VALUES ('8', 'security', 'laokou-security', 'TEST2', '样例部门2', 'apollo', 'apollo@acme.com', '', 'apollo', '2022-11-04 18:43:16', 'apollo', '2022-11-21 00:27:40');
INSERT INTO `app` VALUES ('9', 'common', 'laokou-common', 'TEST1', '样例部门1', 'apollo', 'apollo@acme.com', '', 'apollo', '2022-11-24 19:41:35', 'apollo', '2022-11-24 20:00:06');
INSERT INTO `app` VALUES ('10', 'auth', 'laokou-auth', 'TEST1', '样例部门1', 'apollo', 'apollo@acme.com', '\0', 'apollo', '2022-11-24 20:03:23', 'apollo', '2022-11-24 20:03:23');
INSERT INTO `app` VALUES ('11', 'common', 'laokou-common', 'TEST1', '样例部门1', 'apollo', 'apollo@acme.com', '\0', 'apollo', '2022-11-24 20:16:58', 'apollo', '2022-11-24 20:16:58');

-- ----------------------------
-- Table structure for appnamespace
-- ----------------------------
DROP TABLE IF EXISTS `appnamespace`;
CREATE TABLE `appnamespace` (
  `Id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `Name` varchar(32) NOT NULL DEFAULT '' COMMENT 'namespace名字，注意，需要全局唯一',
  `AppId` varchar(32) NOT NULL DEFAULT '' COMMENT 'app id',
  `Format` varchar(32) NOT NULL DEFAULT 'properties' COMMENT 'namespace的format类型',
  `IsPublic` bit(1) NOT NULL DEFAULT b'0' COMMENT 'namespace是否为公共',
  `Comment` varchar(64) NOT NULL DEFAULT '' COMMENT '注释',
  `IsDeleted` bit(1) NOT NULL DEFAULT b'0' COMMENT '1: deleted, 0: normal',
  `DataChange_CreatedBy` varchar(32) NOT NULL DEFAULT '' COMMENT '创建人邮箱前缀',
  `DataChange_CreatedTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `DataChange_LastModifiedBy` varchar(32) DEFAULT '' COMMENT '最后修改人邮箱前缀',
  `DataChange_LastTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`Id`),
  KEY `IX_AppId` (`AppId`),
  KEY `Name_AppId` (`Name`,`AppId`),
  KEY `DataChange_LastTime` (`DataChange_LastTime`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COMMENT='应用namespace定义';

-- ----------------------------
-- Records of appnamespace
-- ----------------------------
INSERT INTO `appnamespace` VALUES ('1', 'application', 'SampleApp', 'properties', '\0', 'default app namespace', '', '', '2022-06-25 18:49:12', 'apollo', '2022-06-25 19:28:56');
INSERT INTO `appnamespace` VALUES ('2', 'application', 'admin', 'properties', '\0', 'default app namespace', '\0', 'apollo', '2022-06-25 18:52:07', 'apollo', '2022-06-25 18:52:07');
INSERT INTO `appnamespace` VALUES ('3', 'application', 'gateway', 'properties', '\0', 'default app namespace', '\0', 'apollo', '2022-07-02 13:49:10', 'apollo', '2022-07-02 13:49:10');
INSERT INTO `appnamespace` VALUES ('4', 'application', 'auth', 'properties', '\0', 'default app namespace', '', 'apollo', '2022-07-17 12:20:10', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `appnamespace` VALUES ('5', 'application', 'cas', 'properties', '\0', 'default app namespace', '', 'apollo', '2022-09-25 07:24:09', 'apollo', '2022-10-29 16:50:25');
INSERT INTO `appnamespace` VALUES ('6', 'application', 'elasticsearch', 'properties', '\0', 'default app namespace', '\0', 'apollo', '2022-09-25 07:30:45', 'apollo', '2022-09-25 07:30:45');
INSERT INTO `appnamespace` VALUES ('7', 'application', 'ump', 'properties', '\0', 'default app namespace', '', 'apollo', '2022-10-29 16:48:18', 'apollo', '2022-11-04 18:45:02');
INSERT INTO `appnamespace` VALUES ('8', 'application', 'security', 'properties', '\0', 'default app namespace', '', 'apollo', '2022-11-04 18:43:16', 'apollo', '2022-11-21 00:27:40');
INSERT INTO `appnamespace` VALUES ('9', 'TEST1.laokou-common-redis', 'auth', 'properties', '', '公共redis配置', '', 'apollo', '2022-11-24 18:37:03', 'apollo', '2022-11-24 19:00:48');
INSERT INTO `appnamespace` VALUES ('10', 'TEST1.laokou-common-mysql', 'auth', 'properties', '', 'mysql公共配置', '', 'apollo', '2022-11-24 18:39:50', 'apollo', '2022-11-24 19:00:40');
INSERT INTO `appnamespace` VALUES ('11', 'application-common-mysql', 'auth', 'properties', '', 'mysql公共配置', '', 'apollo', '2022-11-24 18:56:32', 'apollo', '2022-11-24 18:59:43');
INSERT INTO `appnamespace` VALUES ('12', 'application-common-redis', 'auth', 'properties', '', 'redis公共配置', '', 'apollo', '2022-11-24 18:57:55', 'apollo', '2022-11-24 19:23:40');
INSERT INTO `appnamespace` VALUES ('13', 'application-common-mysql', 'auth', 'properties', '', 'mysql公共配置', '', 'apollo', '2022-11-24 19:00:09', 'apollo', '2022-11-24 19:23:47');
INSERT INTO `appnamespace` VALUES ('14', 'TEST1.application-common-mysql', 'auth', 'properties', '', 'mysql公共配置', '', 'apollo', '2022-11-24 19:35:19', 'apollo', '2022-11-24 19:42:41');
INSERT INTO `appnamespace` VALUES ('15', 'application', 'common', 'properties', '\0', 'default app namespace', '', 'apollo', '2022-11-24 19:41:35', 'apollo', '2022-11-24 20:00:06');
INSERT INTO `appnamespace` VALUES ('16', 'application-common-mysql', 'common', 'properties', '', 'mysql公共配置', '', 'apollo', '2022-11-24 19:43:27', 'apollo', '2022-11-24 19:59:51');
INSERT INTO `appnamespace` VALUES ('17', 'application', 'auth', 'properties', '\0', 'default app namespace', '\0', 'apollo', '2022-11-24 20:03:23', 'apollo', '2022-11-24 20:03:23');
INSERT INTO `appnamespace` VALUES ('18', 'application', 'common', 'properties', '\0', 'default app namespace', '\0', 'apollo', '2022-11-24 20:16:58', 'apollo', '2022-11-24 20:16:58');
INSERT INTO `appnamespace` VALUES ('19', 'application-common', 'common', 'properties', '', '公共配置', '\0', 'apollo', '2022-11-24 20:20:10', 'apollo', '2022-11-24 20:20:10');
INSERT INTO `appnamespace` VALUES ('20', 'application-redis', 'gateway', 'properties', '\0', 'redis配置', '', 'apollo', '2022-11-24 21:00:18', 'apollo', '2022-11-24 21:01:53');
INSERT INTO `appnamespace` VALUES ('21', 'application-common-redis', 'common', 'properties', '', 'redis公共配置', '\0', 'apollo', '2022-11-24 21:08:48', 'apollo', '2022-11-24 21:08:48');
INSERT INTO `appnamespace` VALUES ('22', 'application-common-elasticsearch', 'common', 'properties', '', 'elasticsearch公共配置', '\0', 'apollo', '2022-11-24 21:24:33', 'apollo', '2022-11-24 21:24:33');

-- ----------------------------
-- Table structure for authorities
-- ----------------------------
DROP TABLE IF EXISTS `authorities`;
CREATE TABLE `authorities` (
  `Id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增Id',
  `Username` varchar(64) NOT NULL,
  `Authority` varchar(50) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of authorities
-- ----------------------------
INSERT INTO `authorities` VALUES ('1', 'apollo', 'ROLE_user');
INSERT INTO `authorities` VALUES ('2', 'root', 'ROLE_user');
INSERT INTO `authorities` VALUES ('3', 'root', 'ROLE_user');

-- ----------------------------
-- Table structure for consumer
-- ----------------------------
DROP TABLE IF EXISTS `consumer`;
CREATE TABLE `consumer` (
  `Id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增Id',
  `AppId` varchar(500) NOT NULL DEFAULT 'default' COMMENT 'AppID',
  `Name` varchar(500) NOT NULL DEFAULT 'default' COMMENT '应用名',
  `OrgId` varchar(32) NOT NULL DEFAULT 'default' COMMENT '部门Id',
  `OrgName` varchar(64) NOT NULL DEFAULT 'default' COMMENT '部门名字',
  `OwnerName` varchar(500) NOT NULL DEFAULT 'default' COMMENT 'ownerName',
  `OwnerEmail` varchar(500) NOT NULL DEFAULT 'default' COMMENT 'ownerEmail',
  `IsDeleted` bit(1) NOT NULL DEFAULT b'0' COMMENT '1: deleted, 0: normal',
  `DataChange_CreatedBy` varchar(32) NOT NULL DEFAULT 'default' COMMENT '创建人邮箱前缀',
  `DataChange_CreatedTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `DataChange_LastModifiedBy` varchar(32) DEFAULT '' COMMENT '最后修改人邮箱前缀',
  `DataChange_LastTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`Id`),
  KEY `AppId` (`AppId`(191)),
  KEY `DataChange_LastTime` (`DataChange_LastTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='开放API消费者';

-- ----------------------------
-- Records of consumer
-- ----------------------------

-- ----------------------------
-- Table structure for consumeraudit
-- ----------------------------
DROP TABLE IF EXISTS `consumeraudit`;
CREATE TABLE `consumeraudit` (
  `Id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增Id',
  `ConsumerId` int(11) unsigned DEFAULT NULL COMMENT 'Consumer Id',
  `Uri` varchar(1024) NOT NULL DEFAULT '' COMMENT '访问的Uri',
  `Method` varchar(16) NOT NULL DEFAULT '' COMMENT '访问的Method',
  `DataChange_CreatedTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `DataChange_LastTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`Id`),
  KEY `IX_DataChange_LastTime` (`DataChange_LastTime`),
  KEY `IX_ConsumerId` (`ConsumerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='consumer审计表';

-- ----------------------------
-- Records of consumeraudit
-- ----------------------------

-- ----------------------------
-- Table structure for consumerrole
-- ----------------------------
DROP TABLE IF EXISTS `consumerrole`;
CREATE TABLE `consumerrole` (
  `Id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增Id',
  `ConsumerId` int(11) unsigned DEFAULT NULL COMMENT 'Consumer Id',
  `RoleId` int(10) unsigned DEFAULT NULL COMMENT 'Role Id',
  `IsDeleted` bit(1) NOT NULL DEFAULT b'0' COMMENT '1: deleted, 0: normal',
  `DataChange_CreatedBy` varchar(32) DEFAULT '' COMMENT '创建人邮箱前缀',
  `DataChange_CreatedTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `DataChange_LastModifiedBy` varchar(32) DEFAULT '' COMMENT '最后修改人邮箱前缀',
  `DataChange_LastTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`Id`),
  KEY `IX_DataChange_LastTime` (`DataChange_LastTime`),
  KEY `IX_RoleId` (`RoleId`),
  KEY `IX_ConsumerId_RoleId` (`ConsumerId`,`RoleId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='consumer和role的绑定表';

-- ----------------------------
-- Records of consumerrole
-- ----------------------------

-- ----------------------------
-- Table structure for consumertoken
-- ----------------------------
DROP TABLE IF EXISTS `consumertoken`;
CREATE TABLE `consumertoken` (
  `Id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增Id',
  `ConsumerId` int(11) unsigned DEFAULT NULL COMMENT 'ConsumerId',
  `Token` varchar(128) NOT NULL DEFAULT '' COMMENT 'token',
  `Expires` datetime NOT NULL DEFAULT '2099-01-01 00:00:00' COMMENT 'token失效时间',
  `IsDeleted` bit(1) NOT NULL DEFAULT b'0' COMMENT '1: deleted, 0: normal',
  `DataChange_CreatedBy` varchar(32) NOT NULL DEFAULT 'default' COMMENT '创建人邮箱前缀',
  `DataChange_CreatedTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `DataChange_LastModifiedBy` varchar(32) DEFAULT '' COMMENT '最后修改人邮箱前缀',
  `DataChange_LastTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_Token` (`Token`),
  KEY `DataChange_LastTime` (`DataChange_LastTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='consumer token表';

-- ----------------------------
-- Records of consumertoken
-- ----------------------------

-- ----------------------------
-- Table structure for favorite
-- ----------------------------
DROP TABLE IF EXISTS `favorite`;
CREATE TABLE `favorite` (
  `Id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `UserId` varchar(32) NOT NULL DEFAULT 'default' COMMENT '收藏的用户',
  `AppId` varchar(500) NOT NULL DEFAULT 'default' COMMENT 'AppID',
  `Position` int(32) NOT NULL DEFAULT '10000' COMMENT '收藏顺序',
  `IsDeleted` bit(1) NOT NULL DEFAULT b'0' COMMENT '1: deleted, 0: normal',
  `DataChange_CreatedBy` varchar(32) NOT NULL DEFAULT 'default' COMMENT '创建人邮箱前缀',
  `DataChange_CreatedTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `DataChange_LastModifiedBy` varchar(32) DEFAULT '' COMMENT '最后修改人邮箱前缀',
  `DataChange_LastTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`Id`),
  KEY `AppId` (`AppId`(191)),
  KEY `IX_UserId` (`UserId`),
  KEY `DataChange_LastTime` (`DataChange_LastTime`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COMMENT='应用收藏表';

-- ----------------------------
-- Records of favorite
-- ----------------------------
INSERT INTO `favorite` VALUES ('1', 'apollo', 'elasticsearch', '10000', '\0', 'apollo', '2022-10-29 16:53:12', 'apollo', '2022-10-29 16:53:12');
INSERT INTO `favorite` VALUES ('2', 'apollo', 'auth', '9993', '', 'apollo', '2022-10-29 16:53:23', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `favorite` VALUES ('3', 'apollo', 'admin', '9994', '\0', 'apollo', '2022-10-29 16:53:27', 'apollo', '2022-10-29 16:54:14');
INSERT INTO `favorite` VALUES ('4', 'apollo', 'gateway', '9995', '\0', 'apollo', '2022-10-29 16:53:31', 'apollo', '2022-10-29 16:54:11');
INSERT INTO `favorite` VALUES ('5', 'apollo', 'ump', '9996', '', 'apollo', '2022-10-29 16:53:44', 'apollo', '2022-11-04 18:45:02');
INSERT INTO `favorite` VALUES ('6', 'apollo', 'security', '10000', '', 'apollo', '2022-11-04 18:45:12', 'apollo', '2022-11-21 00:27:40');
INSERT INTO `favorite` VALUES ('7', 'apollo', 'auth', '10000', '\0', 'apollo', '2022-11-24 20:04:51', 'apollo', '2022-11-24 20:04:51');
INSERT INTO `favorite` VALUES ('8', 'apollo', 'common', '10000', '\0', 'apollo', '2022-11-24 21:15:45', 'apollo', '2022-11-24 21:15:45');

-- ----------------------------
-- Table structure for permission
-- ----------------------------
DROP TABLE IF EXISTS `permission`;
CREATE TABLE `permission` (
  `Id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增Id',
  `PermissionType` varchar(32) NOT NULL DEFAULT '' COMMENT '权限类型',
  `TargetId` varchar(256) NOT NULL DEFAULT '' COMMENT '权限对象类型',
  `IsDeleted` bit(1) NOT NULL DEFAULT b'0' COMMENT '1: deleted, 0: normal',
  `DataChange_CreatedBy` varchar(32) NOT NULL DEFAULT '' COMMENT '创建人邮箱前缀',
  `DataChange_CreatedTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `DataChange_LastModifiedBy` varchar(32) DEFAULT '' COMMENT '最后修改人邮箱前缀',
  `DataChange_LastTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`Id`),
  KEY `IX_TargetId_PermissionType` (`TargetId`(191),`PermissionType`),
  KEY `IX_DataChange_LastTime` (`DataChange_LastTime`)
) ENGINE=InnoDB AUTO_INCREMENT=163 DEFAULT CHARSET=utf8mb4 COMMENT='permission表';

-- ----------------------------
-- Records of permission
-- ----------------------------
INSERT INTO `permission` VALUES ('1', 'CreateCluster', 'SampleApp', '', '', '2022-06-25 18:49:12', 'apollo', '2022-06-25 19:28:56');
INSERT INTO `permission` VALUES ('2', 'CreateNamespace', 'SampleApp', '', '', '2022-06-25 18:49:12', 'apollo', '2022-06-25 19:28:56');
INSERT INTO `permission` VALUES ('3', 'AssignRole', 'SampleApp', '', '', '2022-06-25 18:49:12', 'apollo', '2022-06-25 19:28:56');
INSERT INTO `permission` VALUES ('4', 'ModifyNamespace', 'SampleApp+application', '', '', '2022-06-25 18:49:12', 'apollo', '2022-06-25 19:28:56');
INSERT INTO `permission` VALUES ('5', 'ReleaseNamespace', 'SampleApp+application', '', '', '2022-06-25 18:49:12', 'apollo', '2022-06-25 19:28:56');
INSERT INTO `permission` VALUES ('6', 'CreateApplication', 'SystemRole', '\0', 'apollo', '2022-06-25 18:51:06', 'apollo', '2022-06-25 18:51:06');
INSERT INTO `permission` VALUES ('7', 'AssignRole', 'admin', '\0', 'apollo', '2022-06-25 18:52:07', 'apollo', '2022-06-25 18:52:07');
INSERT INTO `permission` VALUES ('8', 'CreateCluster', 'admin', '\0', 'apollo', '2022-06-25 18:52:07', 'apollo', '2022-06-25 18:52:07');
INSERT INTO `permission` VALUES ('9', 'CreateNamespace', 'admin', '\0', 'apollo', '2022-06-25 18:52:07', 'apollo', '2022-06-25 18:52:07');
INSERT INTO `permission` VALUES ('10', 'ManageAppMaster', 'admin', '\0', 'apollo', '2022-06-25 18:52:07', 'apollo', '2022-06-25 18:52:07');
INSERT INTO `permission` VALUES ('11', 'ModifyNamespace', 'admin+application', '\0', 'apollo', '2022-06-25 18:52:07', 'apollo', '2022-06-25 18:52:07');
INSERT INTO `permission` VALUES ('12', 'ReleaseNamespace', 'admin+application', '\0', 'apollo', '2022-06-25 18:52:07', 'apollo', '2022-06-25 18:52:07');
INSERT INTO `permission` VALUES ('13', 'ModifyNamespace', 'admin+application+DEV', '\0', 'apollo', '2022-06-25 18:52:07', 'apollo', '2022-06-25 18:52:07');
INSERT INTO `permission` VALUES ('14', 'ReleaseNamespace', 'admin+application+DEV', '\0', 'apollo', '2022-06-25 18:52:07', 'apollo', '2022-06-25 18:52:07');
INSERT INTO `permission` VALUES ('15', 'CreateNamespace', 'gateway', '\0', 'apollo', '2022-07-02 13:49:10', 'apollo', '2022-07-02 13:49:10');
INSERT INTO `permission` VALUES ('16', 'CreateCluster', 'gateway', '\0', 'apollo', '2022-07-02 13:49:10', 'apollo', '2022-07-02 13:49:10');
INSERT INTO `permission` VALUES ('17', 'AssignRole', 'gateway', '\0', 'apollo', '2022-07-02 13:49:10', 'apollo', '2022-07-02 13:49:10');
INSERT INTO `permission` VALUES ('18', 'ManageAppMaster', 'gateway', '\0', 'apollo', '2022-07-02 13:49:10', 'apollo', '2022-07-02 13:49:10');
INSERT INTO `permission` VALUES ('19', 'ModifyNamespace', 'gateway+application', '\0', 'apollo', '2022-07-02 13:49:10', 'apollo', '2022-07-02 13:49:10');
INSERT INTO `permission` VALUES ('20', 'ReleaseNamespace', 'gateway+application', '\0', 'apollo', '2022-07-02 13:49:10', 'apollo', '2022-07-02 13:49:10');
INSERT INTO `permission` VALUES ('21', 'ModifyNamespace', 'gateway+application+DEV', '\0', 'apollo', '2022-07-02 13:49:10', 'apollo', '2022-07-02 13:49:10');
INSERT INTO `permission` VALUES ('22', 'ReleaseNamespace', 'gateway+application+DEV', '\0', 'apollo', '2022-07-02 13:49:10', 'apollo', '2022-07-02 13:49:10');
INSERT INTO `permission` VALUES ('23', 'CreateCluster', 'auth', '', 'apollo', '2022-07-17 12:20:10', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `permission` VALUES ('24', 'AssignRole', 'auth', '', 'apollo', '2022-07-17 12:20:10', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `permission` VALUES ('25', 'CreateNamespace', 'auth', '', 'apollo', '2022-07-17 12:20:10', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `permission` VALUES ('26', 'ManageAppMaster', 'auth', '', 'apollo', '2022-07-17 12:20:10', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `permission` VALUES ('27', 'ModifyNamespace', 'auth+application', '', 'apollo', '2022-07-17 12:20:10', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `permission` VALUES ('28', 'ReleaseNamespace', 'auth+application', '', 'apollo', '2022-07-17 12:20:10', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `permission` VALUES ('29', 'ModifyNamespace', 'auth+application+DEV', '', 'apollo', '2022-07-17 12:20:10', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `permission` VALUES ('30', 'ReleaseNamespace', 'auth+application+DEV', '', 'apollo', '2022-07-17 12:20:10', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `permission` VALUES ('31', 'CreateNamespace', 'cas', '', 'apollo', '2022-09-25 07:24:09', 'apollo', '2022-10-29 16:50:25');
INSERT INTO `permission` VALUES ('32', 'CreateCluster', 'cas', '', 'apollo', '2022-09-25 07:24:09', 'apollo', '2022-10-29 16:50:25');
INSERT INTO `permission` VALUES ('33', 'AssignRole', 'cas', '', 'apollo', '2022-09-25 07:24:09', 'apollo', '2022-10-29 16:50:25');
INSERT INTO `permission` VALUES ('34', 'ManageAppMaster', 'cas', '', 'apollo', '2022-09-25 07:24:09', 'apollo', '2022-10-29 16:50:25');
INSERT INTO `permission` VALUES ('35', 'ModifyNamespace', 'cas+application', '', 'apollo', '2022-09-25 07:24:09', 'apollo', '2022-10-29 16:50:25');
INSERT INTO `permission` VALUES ('36', 'ReleaseNamespace', 'cas+application', '', 'apollo', '2022-09-25 07:24:09', 'apollo', '2022-10-29 16:50:25');
INSERT INTO `permission` VALUES ('37', 'ModifyNamespace', 'cas+application+DEV', '', 'apollo', '2022-09-25 07:24:09', 'apollo', '2022-10-29 16:50:25');
INSERT INTO `permission` VALUES ('38', 'ReleaseNamespace', 'cas+application+DEV', '', 'apollo', '2022-09-25 07:24:09', 'apollo', '2022-10-29 16:50:25');
INSERT INTO `permission` VALUES ('39', 'CreateCluster', 'elasticsearch', '\0', 'apollo', '2022-09-25 07:30:45', 'apollo', '2022-09-25 07:30:45');
INSERT INTO `permission` VALUES ('40', 'CreateNamespace', 'elasticsearch', '\0', 'apollo', '2022-09-25 07:30:45', 'apollo', '2022-09-25 07:30:45');
INSERT INTO `permission` VALUES ('41', 'AssignRole', 'elasticsearch', '\0', 'apollo', '2022-09-25 07:30:45', 'apollo', '2022-09-25 07:30:45');
INSERT INTO `permission` VALUES ('42', 'ManageAppMaster', 'elasticsearch', '\0', 'apollo', '2022-09-25 07:30:45', 'apollo', '2022-09-25 07:30:45');
INSERT INTO `permission` VALUES ('43', 'ModifyNamespace', 'elasticsearch+application', '\0', 'apollo', '2022-09-25 07:30:45', 'apollo', '2022-09-25 07:30:45');
INSERT INTO `permission` VALUES ('44', 'ReleaseNamespace', 'elasticsearch+application', '\0', 'apollo', '2022-09-25 07:30:45', 'apollo', '2022-09-25 07:30:45');
INSERT INTO `permission` VALUES ('45', 'ModifyNamespace', 'elasticsearch+application+DEV', '\0', 'apollo', '2022-09-25 07:30:45', 'apollo', '2022-09-25 07:30:45');
INSERT INTO `permission` VALUES ('46', 'ReleaseNamespace', 'elasticsearch+application+DEV', '\0', 'apollo', '2022-09-25 07:30:45', 'apollo', '2022-09-25 07:30:45');
INSERT INTO `permission` VALUES ('47', 'CreateCluster', 'ump', '', 'apollo', '2022-10-29 16:48:18', 'apollo', '2022-11-04 18:45:02');
INSERT INTO `permission` VALUES ('48', 'CreateNamespace', 'ump', '', 'apollo', '2022-10-29 16:48:18', 'apollo', '2022-11-04 18:45:02');
INSERT INTO `permission` VALUES ('49', 'AssignRole', 'ump', '', 'apollo', '2022-10-29 16:48:18', 'apollo', '2022-11-04 18:45:02');
INSERT INTO `permission` VALUES ('50', 'ManageAppMaster', 'ump', '', 'apollo', '2022-10-29 16:48:19', 'apollo', '2022-11-04 18:45:02');
INSERT INTO `permission` VALUES ('51', 'ModifyNamespace', 'ump+application', '', 'apollo', '2022-10-29 16:48:19', 'apollo', '2022-11-04 18:45:02');
INSERT INTO `permission` VALUES ('52', 'ReleaseNamespace', 'ump+application', '', 'apollo', '2022-10-29 16:48:19', 'apollo', '2022-11-04 18:45:02');
INSERT INTO `permission` VALUES ('53', 'ModifyNamespace', 'ump+application+DEV', '', 'apollo', '2022-10-29 16:48:19', 'apollo', '2022-11-04 18:45:02');
INSERT INTO `permission` VALUES ('54', 'ReleaseNamespace', 'ump+application+DEV', '', 'apollo', '2022-10-29 16:48:19', 'apollo', '2022-11-04 18:45:02');
INSERT INTO `permission` VALUES ('55', 'AssignRole', 'security', '', 'apollo', '2022-11-04 18:43:16', 'apollo', '2022-11-21 00:27:40');
INSERT INTO `permission` VALUES ('56', 'CreateNamespace', 'security', '', 'apollo', '2022-11-04 18:43:16', 'apollo', '2022-11-21 00:27:40');
INSERT INTO `permission` VALUES ('57', 'CreateCluster', 'security', '', 'apollo', '2022-11-04 18:43:16', 'apollo', '2022-11-21 00:27:40');
INSERT INTO `permission` VALUES ('58', 'ManageAppMaster', 'security', '', 'apollo', '2022-11-04 18:43:16', 'apollo', '2022-11-21 00:27:40');
INSERT INTO `permission` VALUES ('59', 'ModifyNamespace', 'security+application', '', 'apollo', '2022-11-04 18:43:16', 'apollo', '2022-11-21 00:27:40');
INSERT INTO `permission` VALUES ('60', 'ReleaseNamespace', 'security+application', '', 'apollo', '2022-11-04 18:43:16', 'apollo', '2022-11-21 00:27:40');
INSERT INTO `permission` VALUES ('61', 'ModifyNamespace', 'security+application+DEV', '', 'apollo', '2022-11-04 18:43:16', 'apollo', '2022-11-21 00:27:40');
INSERT INTO `permission` VALUES ('62', 'ReleaseNamespace', 'security+application+DEV', '', 'apollo', '2022-11-04 18:43:16', 'apollo', '2022-11-21 00:27:40');
INSERT INTO `permission` VALUES ('63', 'ModifyNamespace', 'auth+TEST1.laokou-common-redis', '', 'apollo', '2022-11-24 18:37:03', 'apollo', '2022-11-24 19:00:48');
INSERT INTO `permission` VALUES ('64', 'ReleaseNamespace', 'auth+TEST1.laokou-common-redis', '', 'apollo', '2022-11-24 18:37:03', 'apollo', '2022-11-24 19:00:48');
INSERT INTO `permission` VALUES ('65', 'ModifyNamespace', 'auth+TEST1.laokou-common-redis+DEV', '', 'apollo', '2022-11-24 18:37:03', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `permission` VALUES ('66', 'ReleaseNamespace', 'auth+TEST1.laokou-common-redis+DEV', '', 'apollo', '2022-11-24 18:37:03', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `permission` VALUES ('67', 'ModifyNamespace', 'auth+TEST1.laokou-common-mysql', '', 'apollo', '2022-11-24 18:39:50', 'apollo', '2022-11-24 19:00:40');
INSERT INTO `permission` VALUES ('68', 'ReleaseNamespace', 'auth+TEST1.laokou-common-mysql', '', 'apollo', '2022-11-24 18:39:50', 'apollo', '2022-11-24 19:00:40');
INSERT INTO `permission` VALUES ('69', 'ModifyNamespace', 'auth+TEST1.laokou-common-mysql+DEV', '', 'apollo', '2022-11-24 18:39:50', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `permission` VALUES ('70', 'ReleaseNamespace', 'auth+TEST1.laokou-common-mysql+DEV', '', 'apollo', '2022-11-24 18:39:50', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `permission` VALUES ('71', 'ModifyNamespace', 'gateway+TEST1.laokou-common-redis', '\0', 'apollo', '2022-11-24 18:41:46', 'apollo', '2022-11-24 18:41:46');
INSERT INTO `permission` VALUES ('72', 'ReleaseNamespace', 'gateway+TEST1.laokou-common-redis', '\0', 'apollo', '2022-11-24 18:41:46', 'apollo', '2022-11-24 18:41:46');
INSERT INTO `permission` VALUES ('73', 'ModifyNamespace', 'gateway+TEST1.laokou-common-redis+DEV', '\0', 'apollo', '2022-11-24 18:41:46', 'apollo', '2022-11-24 18:41:46');
INSERT INTO `permission` VALUES ('74', 'ReleaseNamespace', 'gateway+TEST1.laokou-common-redis+DEV', '\0', 'apollo', '2022-11-24 18:41:46', 'apollo', '2022-11-24 18:41:46');
INSERT INTO `permission` VALUES ('75', 'ModifyNamespace', 'admin+TEST1.laokou-common-redis', '\0', 'apollo', '2022-11-24 18:42:44', 'apollo', '2022-11-24 18:42:44');
INSERT INTO `permission` VALUES ('76', 'ReleaseNamespace', 'admin+TEST1.laokou-common-redis', '\0', 'apollo', '2022-11-24 18:42:44', 'apollo', '2022-11-24 18:42:44');
INSERT INTO `permission` VALUES ('77', 'ModifyNamespace', 'admin+TEST1.laokou-common-redis+DEV', '\0', 'apollo', '2022-11-24 18:42:44', 'apollo', '2022-11-24 18:42:44');
INSERT INTO `permission` VALUES ('78', 'ReleaseNamespace', 'admin+TEST1.laokou-common-redis+DEV', '\0', 'apollo', '2022-11-24 18:42:44', 'apollo', '2022-11-24 18:42:44');
INSERT INTO `permission` VALUES ('79', 'ModifyNamespace', 'admin+TEST1.laokou-common-mysql', '\0', 'apollo', '2022-11-24 18:42:51', 'apollo', '2022-11-24 18:42:51');
INSERT INTO `permission` VALUES ('80', 'ReleaseNamespace', 'admin+TEST1.laokou-common-mysql', '\0', 'apollo', '2022-11-24 18:42:51', 'apollo', '2022-11-24 18:42:51');
INSERT INTO `permission` VALUES ('81', 'ModifyNamespace', 'admin+TEST1.laokou-common-mysql+DEV', '\0', 'apollo', '2022-11-24 18:42:51', 'apollo', '2022-11-24 18:42:51');
INSERT INTO `permission` VALUES ('82', 'ReleaseNamespace', 'admin+TEST1.laokou-common-mysql+DEV', '\0', 'apollo', '2022-11-24 18:42:51', 'apollo', '2022-11-24 18:42:51');
INSERT INTO `permission` VALUES ('83', 'ModifyNamespace', 'auth+application-common-mysql', '', 'apollo', '2022-11-24 18:56:32', 'apollo', '2022-11-24 18:59:43');
INSERT INTO `permission` VALUES ('84', 'ReleaseNamespace', 'auth+application-common-mysql', '', 'apollo', '2022-11-24 18:56:32', 'apollo', '2022-11-24 18:59:43');
INSERT INTO `permission` VALUES ('85', 'ModifyNamespace', 'auth+application-common-mysql+DEV', '', 'apollo', '2022-11-24 18:56:32', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `permission` VALUES ('86', 'ReleaseNamespace', 'auth+application-common-mysql+DEV', '', 'apollo', '2022-11-24 18:56:32', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `permission` VALUES ('87', 'ModifyNamespace', 'auth+application-common-redis', '', 'apollo', '2022-11-24 18:57:55', 'apollo', '2022-11-24 19:23:40');
INSERT INTO `permission` VALUES ('88', 'ReleaseNamespace', 'auth+application-common-redis', '', 'apollo', '2022-11-24 18:57:56', 'apollo', '2022-11-24 19:23:40');
INSERT INTO `permission` VALUES ('89', 'ModifyNamespace', 'auth+application-common-redis+DEV', '', 'apollo', '2022-11-24 18:57:56', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `permission` VALUES ('90', 'ReleaseNamespace', 'auth+application-common-redis+DEV', '', 'apollo', '2022-11-24 18:57:56', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `permission` VALUES ('91', 'ModifyNamespace', 'auth+application-common-mysql', '', 'apollo', '2022-11-24 19:00:09', 'apollo', '2022-11-24 19:23:47');
INSERT INTO `permission` VALUES ('92', 'ReleaseNamespace', 'auth+application-common-mysql', '', 'apollo', '2022-11-24 19:00:09', 'apollo', '2022-11-24 19:23:47');
INSERT INTO `permission` VALUES ('93', 'ModifyNamespace', 'auth+TEST1.application-common-mysql', '', 'apollo', '2022-11-24 19:35:19', 'apollo', '2022-11-24 19:42:41');
INSERT INTO `permission` VALUES ('94', 'ReleaseNamespace', 'auth+TEST1.application-common-mysql', '', 'apollo', '2022-11-24 19:35:19', 'apollo', '2022-11-24 19:42:41');
INSERT INTO `permission` VALUES ('95', 'ModifyNamespace', 'auth+TEST1.application-common-mysql+DEV', '', 'apollo', '2022-11-24 19:35:19', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `permission` VALUES ('96', 'ReleaseNamespace', 'auth+TEST1.application-common-mysql+DEV', '', 'apollo', '2022-11-24 19:35:19', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `permission` VALUES ('97', 'AssignRole', 'common', '', 'apollo', '2022-11-24 19:41:35', 'apollo', '2022-11-24 20:00:06');
INSERT INTO `permission` VALUES ('98', 'CreateCluster', 'common', '', 'apollo', '2022-11-24 19:41:35', 'apollo', '2022-11-24 20:00:06');
INSERT INTO `permission` VALUES ('99', 'CreateNamespace', 'common', '', 'apollo', '2022-11-24 19:41:35', 'apollo', '2022-11-24 20:00:06');
INSERT INTO `permission` VALUES ('100', 'ManageAppMaster', 'common', '', 'apollo', '2022-11-24 19:41:35', 'apollo', '2022-11-24 20:00:06');
INSERT INTO `permission` VALUES ('101', 'ModifyNamespace', 'common+application', '', 'apollo', '2022-11-24 19:41:35', 'apollo', '2022-11-24 20:00:06');
INSERT INTO `permission` VALUES ('102', 'ReleaseNamespace', 'common+application', '', 'apollo', '2022-11-24 19:41:35', 'apollo', '2022-11-24 20:00:06');
INSERT INTO `permission` VALUES ('103', 'ModifyNamespace', 'common+application+DEV', '', 'apollo', '2022-11-24 19:41:35', 'apollo', '2022-11-24 20:00:06');
INSERT INTO `permission` VALUES ('104', 'ReleaseNamespace', 'common+application+DEV', '', 'apollo', '2022-11-24 19:41:35', 'apollo', '2022-11-24 20:00:06');
INSERT INTO `permission` VALUES ('105', 'ModifyNamespace', 'common+application-common-mysql', '', 'apollo', '2022-11-24 19:43:27', 'apollo', '2022-11-24 19:59:51');
INSERT INTO `permission` VALUES ('106', 'ReleaseNamespace', 'common+application-common-mysql', '', 'apollo', '2022-11-24 19:43:27', 'apollo', '2022-11-24 19:59:51');
INSERT INTO `permission` VALUES ('107', 'ModifyNamespace', 'common+application-common-mysql+DEV', '', 'apollo', '2022-11-24 19:43:27', 'apollo', '2022-11-24 20:00:06');
INSERT INTO `permission` VALUES ('108', 'ReleaseNamespace', 'common+application-common-mysql+DEV', '', 'apollo', '2022-11-24 19:43:27', 'apollo', '2022-11-24 20:00:06');
INSERT INTO `permission` VALUES ('109', 'ModifyNamespace', 'auth+application-common-mysql', '', 'apollo', '2022-11-24 19:44:26', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `permission` VALUES ('110', 'ReleaseNamespace', 'auth+application-common-mysql', '', 'apollo', '2022-11-24 19:44:26', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `permission` VALUES ('111', 'CreateCluster', 'auth', '\0', 'apollo', '2022-11-24 20:03:23', 'apollo', '2022-11-24 20:03:23');
INSERT INTO `permission` VALUES ('112', 'CreateNamespace', 'auth', '\0', 'apollo', '2022-11-24 20:03:23', 'apollo', '2022-11-24 20:03:23');
INSERT INTO `permission` VALUES ('113', 'AssignRole', 'auth', '\0', 'apollo', '2022-11-24 20:03:23', 'apollo', '2022-11-24 20:03:23');
INSERT INTO `permission` VALUES ('114', 'ManageAppMaster', 'auth', '\0', 'apollo', '2022-11-24 20:03:23', 'apollo', '2022-11-24 20:03:23');
INSERT INTO `permission` VALUES ('115', 'ModifyNamespace', 'auth+application', '\0', 'apollo', '2022-11-24 20:03:23', 'apollo', '2022-11-24 20:03:23');
INSERT INTO `permission` VALUES ('116', 'ReleaseNamespace', 'auth+application', '\0', 'apollo', '2022-11-24 20:03:23', 'apollo', '2022-11-24 20:03:23');
INSERT INTO `permission` VALUES ('117', 'ModifyNamespace', 'auth+application+DEV', '\0', 'apollo', '2022-11-24 20:03:23', 'apollo', '2022-11-24 20:03:23');
INSERT INTO `permission` VALUES ('118', 'ReleaseNamespace', 'auth+application+DEV', '\0', 'apollo', '2022-11-24 20:03:23', 'apollo', '2022-11-24 20:03:23');
INSERT INTO `permission` VALUES ('119', 'AssignRole', 'common', '\0', 'apollo', '2022-11-24 20:16:58', 'apollo', '2022-11-24 20:16:58');
INSERT INTO `permission` VALUES ('120', 'CreateNamespace', 'common', '\0', 'apollo', '2022-11-24 20:16:58', 'apollo', '2022-11-24 20:16:58');
INSERT INTO `permission` VALUES ('121', 'CreateCluster', 'common', '\0', 'apollo', '2022-11-24 20:16:58', 'apollo', '2022-11-24 20:16:58');
INSERT INTO `permission` VALUES ('122', 'ManageAppMaster', 'common', '\0', 'apollo', '2022-11-24 20:16:58', 'apollo', '2022-11-24 20:16:58');
INSERT INTO `permission` VALUES ('123', 'ModifyNamespace', 'common+application', '\0', 'apollo', '2022-11-24 20:16:58', 'apollo', '2022-11-24 20:16:58');
INSERT INTO `permission` VALUES ('124', 'ReleaseNamespace', 'common+application', '\0', 'apollo', '2022-11-24 20:16:58', 'apollo', '2022-11-24 20:16:58');
INSERT INTO `permission` VALUES ('125', 'ModifyNamespace', 'common+application+DEV', '\0', 'apollo', '2022-11-24 20:16:58', 'apollo', '2022-11-24 20:16:58');
INSERT INTO `permission` VALUES ('126', 'ReleaseNamespace', 'common+application+DEV', '\0', 'apollo', '2022-11-24 20:16:58', 'apollo', '2022-11-24 20:16:58');
INSERT INTO `permission` VALUES ('127', 'ModifyNamespace', 'common+application-common', '\0', 'apollo', '2022-11-24 20:20:10', 'apollo', '2022-11-24 20:20:10');
INSERT INTO `permission` VALUES ('128', 'ReleaseNamespace', 'common+application-common', '\0', 'apollo', '2022-11-24 20:20:10', 'apollo', '2022-11-24 20:20:10');
INSERT INTO `permission` VALUES ('129', 'ModifyNamespace', 'common+application-common+DEV', '\0', 'apollo', '2022-11-24 20:20:10', 'apollo', '2022-11-24 20:20:10');
INSERT INTO `permission` VALUES ('130', 'ReleaseNamespace', 'common+application-common+DEV', '\0', 'apollo', '2022-11-24 20:20:10', 'apollo', '2022-11-24 20:20:10');
INSERT INTO `permission` VALUES ('131', 'ModifyNamespace', 'auth+application-common', '\0', 'apollo', '2022-11-24 20:20:52', 'apollo', '2022-11-24 20:20:52');
INSERT INTO `permission` VALUES ('132', 'ReleaseNamespace', 'auth+application-common', '\0', 'apollo', '2022-11-24 20:20:52', 'apollo', '2022-11-24 20:20:52');
INSERT INTO `permission` VALUES ('133', 'ModifyNamespace', 'auth+application-common+DEV', '\0', 'apollo', '2022-11-24 20:20:52', 'apollo', '2022-11-24 20:20:52');
INSERT INTO `permission` VALUES ('134', 'ReleaseNamespace', 'auth+application-common+DEV', '\0', 'apollo', '2022-11-24 20:20:52', 'apollo', '2022-11-24 20:20:52');
INSERT INTO `permission` VALUES ('135', 'ModifyNamespace', 'admin+application-common', '\0', 'apollo', '2022-11-24 20:35:00', 'apollo', '2022-11-24 20:35:00');
INSERT INTO `permission` VALUES ('136', 'ReleaseNamespace', 'admin+application-common', '\0', 'apollo', '2022-11-24 20:35:00', 'apollo', '2022-11-24 20:35:00');
INSERT INTO `permission` VALUES ('137', 'ModifyNamespace', 'admin+application-common+DEV', '\0', 'apollo', '2022-11-24 20:35:00', 'apollo', '2022-11-24 20:35:00');
INSERT INTO `permission` VALUES ('138', 'ReleaseNamespace', 'admin+application-common+DEV', '\0', 'apollo', '2022-11-24 20:35:00', 'apollo', '2022-11-24 20:35:00');
INSERT INTO `permission` VALUES ('139', 'ModifyNamespace', 'gateway+application-redis', '', 'apollo', '2022-11-24 21:00:18', 'apollo', '2022-11-24 21:01:53');
INSERT INTO `permission` VALUES ('140', 'ReleaseNamespace', 'gateway+application-redis', '', 'apollo', '2022-11-24 21:00:18', 'apollo', '2022-11-24 21:01:53');
INSERT INTO `permission` VALUES ('141', 'ModifyNamespace', 'gateway+application-redis+DEV', '\0', 'apollo', '2022-11-24 21:00:18', 'apollo', '2022-11-24 21:00:18');
INSERT INTO `permission` VALUES ('142', 'ReleaseNamespace', 'gateway+application-redis+DEV', '\0', 'apollo', '2022-11-24 21:00:18', 'apollo', '2022-11-24 21:00:18');
INSERT INTO `permission` VALUES ('143', 'ModifyNamespace', 'gateway+application-common', '\0', 'apollo', '2022-11-24 21:04:12', 'apollo', '2022-11-24 21:04:12');
INSERT INTO `permission` VALUES ('144', 'ReleaseNamespace', 'gateway+application-common', '\0', 'apollo', '2022-11-24 21:04:12', 'apollo', '2022-11-24 21:04:12');
INSERT INTO `permission` VALUES ('145', 'ModifyNamespace', 'gateway+application-common+DEV', '\0', 'apollo', '2022-11-24 21:04:12', 'apollo', '2022-11-24 21:04:12');
INSERT INTO `permission` VALUES ('146', 'ReleaseNamespace', 'gateway+application-common+DEV', '\0', 'apollo', '2022-11-24 21:04:12', 'apollo', '2022-11-24 21:04:12');
INSERT INTO `permission` VALUES ('147', 'ModifyNamespace', 'common+application-common-redis', '\0', 'apollo', '2022-11-24 21:08:48', 'apollo', '2022-11-24 21:08:48');
INSERT INTO `permission` VALUES ('148', 'ReleaseNamespace', 'common+application-common-redis', '\0', 'apollo', '2022-11-24 21:08:49', 'apollo', '2022-11-24 21:08:49');
INSERT INTO `permission` VALUES ('149', 'ModifyNamespace', 'common+application-common-redis+DEV', '\0', 'apollo', '2022-11-24 21:08:49', 'apollo', '2022-11-24 21:08:49');
INSERT INTO `permission` VALUES ('150', 'ReleaseNamespace', 'common+application-common-redis+DEV', '\0', 'apollo', '2022-11-24 21:08:49', 'apollo', '2022-11-24 21:08:49');
INSERT INTO `permission` VALUES ('151', 'ModifyNamespace', 'gateway+application-common-redis', '\0', 'apollo', '2022-11-24 21:10:24', 'apollo', '2022-11-24 21:10:24');
INSERT INTO `permission` VALUES ('152', 'ReleaseNamespace', 'gateway+application-common-redis', '\0', 'apollo', '2022-11-24 21:10:24', 'apollo', '2022-11-24 21:10:24');
INSERT INTO `permission` VALUES ('153', 'ModifyNamespace', 'gateway+application-common-redis+DEV', '\0', 'apollo', '2022-11-24 21:10:24', 'apollo', '2022-11-24 21:10:24');
INSERT INTO `permission` VALUES ('154', 'ReleaseNamespace', 'gateway+application-common-redis+DEV', '\0', 'apollo', '2022-11-24 21:10:24', 'apollo', '2022-11-24 21:10:24');
INSERT INTO `permission` VALUES ('155', 'ModifyNamespace', 'common+application-common-elasticsearch', '\0', 'apollo', '2022-11-24 21:24:33', 'apollo', '2022-11-24 21:24:33');
INSERT INTO `permission` VALUES ('156', 'ReleaseNamespace', 'common+application-common-elasticsearch', '\0', 'apollo', '2022-11-24 21:24:33', 'apollo', '2022-11-24 21:24:33');
INSERT INTO `permission` VALUES ('157', 'ModifyNamespace', 'common+application-common-elasticsearch+DEV', '\0', 'apollo', '2022-11-24 21:24:33', 'apollo', '2022-11-24 21:24:33');
INSERT INTO `permission` VALUES ('158', 'ReleaseNamespace', 'common+application-common-elasticsearch+DEV', '\0', 'apollo', '2022-11-24 21:24:33', 'apollo', '2022-11-24 21:24:33');
INSERT INTO `permission` VALUES ('159', 'ModifyNamespace', 'elasticsearch+application-common-elasticsearch', '\0', 'apollo', '2022-11-24 21:26:19', 'apollo', '2022-11-24 21:26:19');
INSERT INTO `permission` VALUES ('160', 'ReleaseNamespace', 'elasticsearch+application-common-elasticsearch', '\0', 'apollo', '2022-11-24 21:26:20', 'apollo', '2022-11-24 21:26:20');
INSERT INTO `permission` VALUES ('161', 'ModifyNamespace', 'elasticsearch+application-common-elasticsearch+DEV', '\0', 'apollo', '2022-11-24 21:26:20', 'apollo', '2022-11-24 21:26:20');
INSERT INTO `permission` VALUES ('162', 'ReleaseNamespace', 'elasticsearch+application-common-elasticsearch+DEV', '\0', 'apollo', '2022-11-24 21:26:20', 'apollo', '2022-11-24 21:26:20');

-- ----------------------------
-- Table structure for role
-- ----------------------------
DROP TABLE IF EXISTS `role`;
CREATE TABLE `role` (
  `Id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增Id',
  `RoleName` varchar(256) NOT NULL DEFAULT '' COMMENT 'Role name',
  `IsDeleted` bit(1) NOT NULL DEFAULT b'0' COMMENT '1: deleted, 0: normal',
  `DataChange_CreatedBy` varchar(32) NOT NULL DEFAULT 'default' COMMENT '创建人邮箱前缀',
  `DataChange_CreatedTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `DataChange_LastModifiedBy` varchar(32) DEFAULT '' COMMENT '最后修改人邮箱前缀',
  `DataChange_LastTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`Id`),
  KEY `IX_RoleName` (`RoleName`(191)),
  KEY `IX_DataChange_LastTime` (`DataChange_LastTime`)
) ENGINE=InnoDB AUTO_INCREMENT=141 DEFAULT CHARSET=utf8mb4 COMMENT='角色表';

-- ----------------------------
-- Records of role
-- ----------------------------
INSERT INTO `role` VALUES ('1', 'Master+SampleApp', '', 'default', '2022-06-25 18:49:12', 'apollo', '2022-06-25 19:28:56');
INSERT INTO `role` VALUES ('2', 'ModifyNamespace+SampleApp+application', '', 'default', '2022-06-25 18:49:12', 'apollo', '2022-06-25 19:28:56');
INSERT INTO `role` VALUES ('3', 'ReleaseNamespace+SampleApp+application', '', 'default', '2022-06-25 18:49:12', 'apollo', '2022-06-25 19:28:56');
INSERT INTO `role` VALUES ('4', 'CreateApplication+SystemRole', '\0', 'apollo', '2022-06-25 18:51:06', 'apollo', '2022-06-25 18:51:06');
INSERT INTO `role` VALUES ('5', 'Master+admin', '\0', 'apollo', '2022-06-25 18:52:07', 'apollo', '2022-06-25 18:52:07');
INSERT INTO `role` VALUES ('6', 'ManageAppMaster+admin', '\0', 'apollo', '2022-06-25 18:52:07', 'apollo', '2022-06-25 18:52:07');
INSERT INTO `role` VALUES ('7', 'ModifyNamespace+admin+application', '\0', 'apollo', '2022-06-25 18:52:07', 'apollo', '2022-06-25 18:52:07');
INSERT INTO `role` VALUES ('8', 'ReleaseNamespace+admin+application', '\0', 'apollo', '2022-06-25 18:52:07', 'apollo', '2022-06-25 18:52:07');
INSERT INTO `role` VALUES ('9', 'ModifyNamespace+admin+application+DEV', '\0', 'apollo', '2022-06-25 18:52:07', 'apollo', '2022-06-25 18:52:07');
INSERT INTO `role` VALUES ('10', 'ReleaseNamespace+admin+application+DEV', '\0', 'apollo', '2022-06-25 18:52:07', 'apollo', '2022-06-25 18:52:07');
INSERT INTO `role` VALUES ('11', 'Master+gateway', '\0', 'apollo', '2022-07-02 13:49:10', 'apollo', '2022-07-02 13:49:10');
INSERT INTO `role` VALUES ('12', 'ManageAppMaster+gateway', '\0', 'apollo', '2022-07-02 13:49:10', 'apollo', '2022-07-02 13:49:10');
INSERT INTO `role` VALUES ('13', 'ModifyNamespace+gateway+application', '\0', 'apollo', '2022-07-02 13:49:10', 'apollo', '2022-07-02 13:49:10');
INSERT INTO `role` VALUES ('14', 'ReleaseNamespace+gateway+application', '\0', 'apollo', '2022-07-02 13:49:10', 'apollo', '2022-07-02 13:49:10');
INSERT INTO `role` VALUES ('15', 'ModifyNamespace+gateway+application+DEV', '\0', 'apollo', '2022-07-02 13:49:10', 'apollo', '2022-07-02 13:49:10');
INSERT INTO `role` VALUES ('16', 'ReleaseNamespace+gateway+application+DEV', '\0', 'apollo', '2022-07-02 13:49:10', 'apollo', '2022-07-02 13:49:10');
INSERT INTO `role` VALUES ('17', 'Master+auth', '', 'apollo', '2022-07-17 12:20:10', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `role` VALUES ('18', 'ManageAppMaster+auth', '', 'apollo', '2022-07-17 12:20:10', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `role` VALUES ('19', 'ModifyNamespace+auth+application', '', 'apollo', '2022-07-17 12:20:10', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `role` VALUES ('20', 'ReleaseNamespace+auth+application', '', 'apollo', '2022-07-17 12:20:10', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `role` VALUES ('21', 'ModifyNamespace+auth+application+DEV', '', 'apollo', '2022-07-17 12:20:10', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `role` VALUES ('22', 'ReleaseNamespace+auth+application+DEV', '', 'apollo', '2022-07-17 12:20:10', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `role` VALUES ('23', 'Master+cas', '', 'apollo', '2022-09-25 07:24:09', 'apollo', '2022-10-29 16:50:25');
INSERT INTO `role` VALUES ('24', 'ManageAppMaster+cas', '', 'apollo', '2022-09-25 07:24:09', 'apollo', '2022-10-29 16:50:25');
INSERT INTO `role` VALUES ('25', 'ModifyNamespace+cas+application', '', 'apollo', '2022-09-25 07:24:09', 'apollo', '2022-10-29 16:50:25');
INSERT INTO `role` VALUES ('26', 'ReleaseNamespace+cas+application', '', 'apollo', '2022-09-25 07:24:09', 'apollo', '2022-10-29 16:50:25');
INSERT INTO `role` VALUES ('27', 'ModifyNamespace+cas+application+DEV', '', 'apollo', '2022-09-25 07:24:09', 'apollo', '2022-10-29 16:50:25');
INSERT INTO `role` VALUES ('28', 'ReleaseNamespace+cas+application+DEV', '', 'apollo', '2022-09-25 07:24:09', 'apollo', '2022-10-29 16:50:25');
INSERT INTO `role` VALUES ('29', 'Master+elasticsearch', '\0', 'apollo', '2022-09-25 07:30:45', 'apollo', '2022-09-25 07:30:45');
INSERT INTO `role` VALUES ('30', 'ManageAppMaster+elasticsearch', '\0', 'apollo', '2022-09-25 07:30:45', 'apollo', '2022-09-25 07:30:45');
INSERT INTO `role` VALUES ('31', 'ModifyNamespace+elasticsearch+application', '\0', 'apollo', '2022-09-25 07:30:45', 'apollo', '2022-09-25 07:30:45');
INSERT INTO `role` VALUES ('32', 'ReleaseNamespace+elasticsearch+application', '\0', 'apollo', '2022-09-25 07:30:45', 'apollo', '2022-09-25 07:30:45');
INSERT INTO `role` VALUES ('33', 'ModifyNamespace+elasticsearch+application+DEV', '\0', 'apollo', '2022-09-25 07:30:45', 'apollo', '2022-09-25 07:30:45');
INSERT INTO `role` VALUES ('34', 'ReleaseNamespace+elasticsearch+application+DEV', '\0', 'apollo', '2022-09-25 07:30:45', 'apollo', '2022-09-25 07:30:45');
INSERT INTO `role` VALUES ('35', 'Master+ump', '', 'apollo', '2022-10-29 16:48:18', 'apollo', '2022-11-04 18:45:02');
INSERT INTO `role` VALUES ('36', 'ManageAppMaster+ump', '', 'apollo', '2022-10-29 16:48:19', 'apollo', '2022-11-04 18:45:02');
INSERT INTO `role` VALUES ('37', 'ModifyNamespace+ump+application', '', 'apollo', '2022-10-29 16:48:19', 'apollo', '2022-11-04 18:45:02');
INSERT INTO `role` VALUES ('38', 'ReleaseNamespace+ump+application', '', 'apollo', '2022-10-29 16:48:19', 'apollo', '2022-11-04 18:45:02');
INSERT INTO `role` VALUES ('39', 'ModifyNamespace+ump+application+DEV', '', 'apollo', '2022-10-29 16:48:19', 'apollo', '2022-11-04 18:45:02');
INSERT INTO `role` VALUES ('40', 'ReleaseNamespace+ump+application+DEV', '', 'apollo', '2022-10-29 16:48:19', 'apollo', '2022-11-04 18:45:02');
INSERT INTO `role` VALUES ('41', 'Master+security', '', 'apollo', '2022-11-04 18:43:16', 'apollo', '2022-11-21 00:27:40');
INSERT INTO `role` VALUES ('42', 'ManageAppMaster+security', '', 'apollo', '2022-11-04 18:43:16', 'apollo', '2022-11-21 00:27:40');
INSERT INTO `role` VALUES ('43', 'ModifyNamespace+security+application', '', 'apollo', '2022-11-04 18:43:16', 'apollo', '2022-11-21 00:27:40');
INSERT INTO `role` VALUES ('44', 'ReleaseNamespace+security+application', '', 'apollo', '2022-11-04 18:43:16', 'apollo', '2022-11-21 00:27:40');
INSERT INTO `role` VALUES ('45', 'ModifyNamespace+security+application+DEV', '', 'apollo', '2022-11-04 18:43:16', 'apollo', '2022-11-21 00:27:40');
INSERT INTO `role` VALUES ('46', 'ReleaseNamespace+security+application+DEV', '', 'apollo', '2022-11-04 18:43:16', 'apollo', '2022-11-21 00:27:40');
INSERT INTO `role` VALUES ('47', 'ModifyNamespace+auth+TEST1.laokou-common-redis', '', 'apollo', '2022-11-24 18:37:03', 'apollo', '2022-11-24 19:00:48');
INSERT INTO `role` VALUES ('48', 'ReleaseNamespace+auth+TEST1.laokou-common-redis', '', 'apollo', '2022-11-24 18:37:03', 'apollo', '2022-11-24 19:00:48');
INSERT INTO `role` VALUES ('49', 'ModifyNamespace+auth+TEST1.laokou-common-redis+DEV', '', 'apollo', '2022-11-24 18:37:03', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `role` VALUES ('50', 'ReleaseNamespace+auth+TEST1.laokou-common-redis+DEV', '', 'apollo', '2022-11-24 18:37:03', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `role` VALUES ('51', 'ModifyNamespace+auth+TEST1.laokou-common-mysql', '', 'apollo', '2022-11-24 18:39:50', 'apollo', '2022-11-24 19:00:40');
INSERT INTO `role` VALUES ('52', 'ReleaseNamespace+auth+TEST1.laokou-common-mysql', '', 'apollo', '2022-11-24 18:39:50', 'apollo', '2022-11-24 19:00:40');
INSERT INTO `role` VALUES ('53', 'ModifyNamespace+auth+TEST1.laokou-common-mysql+DEV', '', 'apollo', '2022-11-24 18:39:50', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `role` VALUES ('54', 'ReleaseNamespace+auth+TEST1.laokou-common-mysql+DEV', '', 'apollo', '2022-11-24 18:39:50', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `role` VALUES ('55', 'ModifyNamespace+gateway+TEST1.laokou-common-redis', '\0', 'apollo', '2022-11-24 18:41:46', 'apollo', '2022-11-24 18:41:46');
INSERT INTO `role` VALUES ('56', 'ReleaseNamespace+gateway+TEST1.laokou-common-redis', '\0', 'apollo', '2022-11-24 18:41:46', 'apollo', '2022-11-24 18:41:46');
INSERT INTO `role` VALUES ('57', 'ModifyNamespace+gateway+TEST1.laokou-common-redis+DEV', '\0', 'apollo', '2022-11-24 18:41:46', 'apollo', '2022-11-24 18:41:46');
INSERT INTO `role` VALUES ('58', 'ReleaseNamespace+gateway+TEST1.laokou-common-redis+DEV', '\0', 'apollo', '2022-11-24 18:41:46', 'apollo', '2022-11-24 18:41:46');
INSERT INTO `role` VALUES ('59', 'ModifyNamespace+admin+TEST1.laokou-common-redis', '\0', 'apollo', '2022-11-24 18:42:44', 'apollo', '2022-11-24 18:42:44');
INSERT INTO `role` VALUES ('60', 'ReleaseNamespace+admin+TEST1.laokou-common-redis', '\0', 'apollo', '2022-11-24 18:42:44', 'apollo', '2022-11-24 18:42:44');
INSERT INTO `role` VALUES ('61', 'ModifyNamespace+admin+TEST1.laokou-common-redis+DEV', '\0', 'apollo', '2022-11-24 18:42:44', 'apollo', '2022-11-24 18:42:44');
INSERT INTO `role` VALUES ('62', 'ReleaseNamespace+admin+TEST1.laokou-common-redis+DEV', '\0', 'apollo', '2022-11-24 18:42:44', 'apollo', '2022-11-24 18:42:44');
INSERT INTO `role` VALUES ('63', 'ModifyNamespace+admin+TEST1.laokou-common-mysql', '\0', 'apollo', '2022-11-24 18:42:51', 'apollo', '2022-11-24 18:42:51');
INSERT INTO `role` VALUES ('64', 'ReleaseNamespace+admin+TEST1.laokou-common-mysql', '\0', 'apollo', '2022-11-24 18:42:51', 'apollo', '2022-11-24 18:42:51');
INSERT INTO `role` VALUES ('65', 'ModifyNamespace+admin+TEST1.laokou-common-mysql+DEV', '\0', 'apollo', '2022-11-24 18:42:51', 'apollo', '2022-11-24 18:42:51');
INSERT INTO `role` VALUES ('66', 'ReleaseNamespace+admin+TEST1.laokou-common-mysql+DEV', '\0', 'apollo', '2022-11-24 18:42:51', 'apollo', '2022-11-24 18:42:51');
INSERT INTO `role` VALUES ('67', 'ModifyNamespace+auth+application-common-mysql', '', 'apollo', '2022-11-24 18:56:32', 'apollo', '2022-11-24 18:59:43');
INSERT INTO `role` VALUES ('68', 'ReleaseNamespace+auth+application-common-mysql', '', 'apollo', '2022-11-24 18:56:32', 'apollo', '2022-11-24 18:59:43');
INSERT INTO `role` VALUES ('69', 'ModifyNamespace+auth+application-common-mysql+DEV', '', 'apollo', '2022-11-24 18:56:32', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `role` VALUES ('70', 'ReleaseNamespace+auth+application-common-mysql+DEV', '', 'apollo', '2022-11-24 18:56:32', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `role` VALUES ('71', 'ModifyNamespace+auth+application-common-redis', '', 'apollo', '2022-11-24 18:57:55', 'apollo', '2022-11-24 19:23:40');
INSERT INTO `role` VALUES ('72', 'ReleaseNamespace+auth+application-common-redis', '', 'apollo', '2022-11-24 18:57:56', 'apollo', '2022-11-24 19:23:40');
INSERT INTO `role` VALUES ('73', 'ModifyNamespace+auth+application-common-redis+DEV', '', 'apollo', '2022-11-24 18:57:56', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `role` VALUES ('74', 'ReleaseNamespace+auth+application-common-redis+DEV', '', 'apollo', '2022-11-24 18:57:56', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `role` VALUES ('75', 'ModifyNamespace+auth+application-common-mysql', '', 'apollo', '2022-11-24 19:00:09', 'apollo', '2022-11-24 19:23:47');
INSERT INTO `role` VALUES ('76', 'ReleaseNamespace+auth+application-common-mysql', '', 'apollo', '2022-11-24 19:00:09', 'apollo', '2022-11-24 19:23:47');
INSERT INTO `role` VALUES ('77', 'ModifyNamespace+auth+TEST1.application-common-mysql', '', 'apollo', '2022-11-24 19:35:19', 'apollo', '2022-11-24 19:42:41');
INSERT INTO `role` VALUES ('78', 'ReleaseNamespace+auth+TEST1.application-common-mysql', '', 'apollo', '2022-11-24 19:35:19', 'apollo', '2022-11-24 19:42:41');
INSERT INTO `role` VALUES ('79', 'ModifyNamespace+auth+TEST1.application-common-mysql+DEV', '', 'apollo', '2022-11-24 19:35:19', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `role` VALUES ('80', 'ReleaseNamespace+auth+TEST1.application-common-mysql+DEV', '', 'apollo', '2022-11-24 19:35:19', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `role` VALUES ('81', 'Master+common', '', 'apollo', '2022-11-24 19:41:35', 'apollo', '2022-11-24 20:00:06');
INSERT INTO `role` VALUES ('82', 'ManageAppMaster+common', '', 'apollo', '2022-11-24 19:41:35', 'apollo', '2022-11-24 20:00:06');
INSERT INTO `role` VALUES ('83', 'ModifyNamespace+common+application', '', 'apollo', '2022-11-24 19:41:35', 'apollo', '2022-11-24 20:00:06');
INSERT INTO `role` VALUES ('84', 'ReleaseNamespace+common+application', '', 'apollo', '2022-11-24 19:41:35', 'apollo', '2022-11-24 20:00:06');
INSERT INTO `role` VALUES ('85', 'ModifyNamespace+common+application+DEV', '', 'apollo', '2022-11-24 19:41:35', 'apollo', '2022-11-24 20:00:06');
INSERT INTO `role` VALUES ('86', 'ReleaseNamespace+common+application+DEV', '', 'apollo', '2022-11-24 19:41:35', 'apollo', '2022-11-24 20:00:06');
INSERT INTO `role` VALUES ('87', 'ModifyNamespace+common+application-common-mysql', '', 'apollo', '2022-11-24 19:43:27', 'apollo', '2022-11-24 19:59:51');
INSERT INTO `role` VALUES ('88', 'ReleaseNamespace+common+application-common-mysql', '', 'apollo', '2022-11-24 19:43:27', 'apollo', '2022-11-24 19:59:51');
INSERT INTO `role` VALUES ('89', 'ModifyNamespace+common+application-common-mysql+DEV', '', 'apollo', '2022-11-24 19:43:27', 'apollo', '2022-11-24 20:00:06');
INSERT INTO `role` VALUES ('90', 'ReleaseNamespace+common+application-common-mysql+DEV', '', 'apollo', '2022-11-24 19:43:27', 'apollo', '2022-11-24 20:00:06');
INSERT INTO `role` VALUES ('91', 'ModifyNamespace+auth+application-common-mysql', '', 'apollo', '2022-11-24 19:44:26', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `role` VALUES ('92', 'ReleaseNamespace+auth+application-common-mysql', '', 'apollo', '2022-11-24 19:44:26', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `role` VALUES ('93', 'Master+auth', '\0', 'apollo', '2022-11-24 20:03:23', 'apollo', '2022-11-24 20:03:23');
INSERT INTO `role` VALUES ('94', 'ManageAppMaster+auth', '\0', 'apollo', '2022-11-24 20:03:23', 'apollo', '2022-11-24 20:03:23');
INSERT INTO `role` VALUES ('95', 'ModifyNamespace+auth+application', '\0', 'apollo', '2022-11-24 20:03:23', 'apollo', '2022-11-24 20:03:23');
INSERT INTO `role` VALUES ('96', 'ReleaseNamespace+auth+application', '\0', 'apollo', '2022-11-24 20:03:23', 'apollo', '2022-11-24 20:03:23');
INSERT INTO `role` VALUES ('97', 'ModifyNamespace+auth+application+DEV', '\0', 'apollo', '2022-11-24 20:03:23', 'apollo', '2022-11-24 20:03:23');
INSERT INTO `role` VALUES ('98', 'ReleaseNamespace+auth+application+DEV', '\0', 'apollo', '2022-11-24 20:03:23', 'apollo', '2022-11-24 20:03:23');
INSERT INTO `role` VALUES ('99', 'Master+common', '\0', 'apollo', '2022-11-24 20:16:58', 'apollo', '2022-11-24 20:16:58');
INSERT INTO `role` VALUES ('100', 'ManageAppMaster+common', '\0', 'apollo', '2022-11-24 20:16:58', 'apollo', '2022-11-24 20:16:58');
INSERT INTO `role` VALUES ('101', 'ModifyNamespace+common+application', '\0', 'apollo', '2022-11-24 20:16:58', 'apollo', '2022-11-24 20:16:58');
INSERT INTO `role` VALUES ('102', 'ReleaseNamespace+common+application', '\0', 'apollo', '2022-11-24 20:16:58', 'apollo', '2022-11-24 20:16:58');
INSERT INTO `role` VALUES ('103', 'ModifyNamespace+common+application+DEV', '\0', 'apollo', '2022-11-24 20:16:58', 'apollo', '2022-11-24 20:16:58');
INSERT INTO `role` VALUES ('104', 'ReleaseNamespace+common+application+DEV', '\0', 'apollo', '2022-11-24 20:16:58', 'apollo', '2022-11-24 20:16:58');
INSERT INTO `role` VALUES ('105', 'ModifyNamespace+common+application-common', '\0', 'apollo', '2022-11-24 20:20:10', 'apollo', '2022-11-24 20:20:10');
INSERT INTO `role` VALUES ('106', 'ReleaseNamespace+common+application-common', '\0', 'apollo', '2022-11-24 20:20:10', 'apollo', '2022-11-24 20:20:10');
INSERT INTO `role` VALUES ('107', 'ModifyNamespace+common+application-common+DEV', '\0', 'apollo', '2022-11-24 20:20:10', 'apollo', '2022-11-24 20:20:10');
INSERT INTO `role` VALUES ('108', 'ReleaseNamespace+common+application-common+DEV', '\0', 'apollo', '2022-11-24 20:20:10', 'apollo', '2022-11-24 20:20:10');
INSERT INTO `role` VALUES ('109', 'ModifyNamespace+auth+application-common', '\0', 'apollo', '2022-11-24 20:20:52', 'apollo', '2022-11-24 20:20:52');
INSERT INTO `role` VALUES ('110', 'ReleaseNamespace+auth+application-common', '\0', 'apollo', '2022-11-24 20:20:52', 'apollo', '2022-11-24 20:20:52');
INSERT INTO `role` VALUES ('111', 'ModifyNamespace+auth+application-common+DEV', '\0', 'apollo', '2022-11-24 20:20:52', 'apollo', '2022-11-24 20:20:52');
INSERT INTO `role` VALUES ('112', 'ReleaseNamespace+auth+application-common+DEV', '\0', 'apollo', '2022-11-24 20:20:52', 'apollo', '2022-11-24 20:20:52');
INSERT INTO `role` VALUES ('113', 'ModifyNamespace+admin+application-common', '\0', 'apollo', '2022-11-24 20:35:00', 'apollo', '2022-11-24 20:35:00');
INSERT INTO `role` VALUES ('114', 'ReleaseNamespace+admin+application-common', '\0', 'apollo', '2022-11-24 20:35:00', 'apollo', '2022-11-24 20:35:00');
INSERT INTO `role` VALUES ('115', 'ModifyNamespace+admin+application-common+DEV', '\0', 'apollo', '2022-11-24 20:35:00', 'apollo', '2022-11-24 20:35:00');
INSERT INTO `role` VALUES ('116', 'ReleaseNamespace+admin+application-common+DEV', '\0', 'apollo', '2022-11-24 20:35:00', 'apollo', '2022-11-24 20:35:00');
INSERT INTO `role` VALUES ('117', 'ModifyNamespace+gateway+application-redis', '', 'apollo', '2022-11-24 21:00:18', 'apollo', '2022-11-24 21:01:53');
INSERT INTO `role` VALUES ('118', 'ReleaseNamespace+gateway+application-redis', '', 'apollo', '2022-11-24 21:00:18', 'apollo', '2022-11-24 21:01:53');
INSERT INTO `role` VALUES ('119', 'ModifyNamespace+gateway+application-redis+DEV', '\0', 'apollo', '2022-11-24 21:00:18', 'apollo', '2022-11-24 21:00:18');
INSERT INTO `role` VALUES ('120', 'ReleaseNamespace+gateway+application-redis+DEV', '\0', 'apollo', '2022-11-24 21:00:18', 'apollo', '2022-11-24 21:00:18');
INSERT INTO `role` VALUES ('121', 'ModifyNamespace+gateway+application-common', '\0', 'apollo', '2022-11-24 21:04:12', 'apollo', '2022-11-24 21:04:12');
INSERT INTO `role` VALUES ('122', 'ReleaseNamespace+gateway+application-common', '\0', 'apollo', '2022-11-24 21:04:12', 'apollo', '2022-11-24 21:04:12');
INSERT INTO `role` VALUES ('123', 'ModifyNamespace+gateway+application-common+DEV', '\0', 'apollo', '2022-11-24 21:04:12', 'apollo', '2022-11-24 21:04:12');
INSERT INTO `role` VALUES ('124', 'ReleaseNamespace+gateway+application-common+DEV', '\0', 'apollo', '2022-11-24 21:04:12', 'apollo', '2022-11-24 21:04:12');
INSERT INTO `role` VALUES ('125', 'ModifyNamespace+common+application-common-redis', '\0', 'apollo', '2022-11-24 21:08:49', 'apollo', '2022-11-24 21:08:49');
INSERT INTO `role` VALUES ('126', 'ReleaseNamespace+common+application-common-redis', '\0', 'apollo', '2022-11-24 21:08:49', 'apollo', '2022-11-24 21:08:49');
INSERT INTO `role` VALUES ('127', 'ModifyNamespace+common+application-common-redis+DEV', '\0', 'apollo', '2022-11-24 21:08:49', 'apollo', '2022-11-24 21:08:49');
INSERT INTO `role` VALUES ('128', 'ReleaseNamespace+common+application-common-redis+DEV', '\0', 'apollo', '2022-11-24 21:08:49', 'apollo', '2022-11-24 21:08:49');
INSERT INTO `role` VALUES ('129', 'ModifyNamespace+gateway+application-common-redis', '\0', 'apollo', '2022-11-24 21:10:24', 'apollo', '2022-11-24 21:10:24');
INSERT INTO `role` VALUES ('130', 'ReleaseNamespace+gateway+application-common-redis', '\0', 'apollo', '2022-11-24 21:10:24', 'apollo', '2022-11-24 21:10:24');
INSERT INTO `role` VALUES ('131', 'ModifyNamespace+gateway+application-common-redis+DEV', '\0', 'apollo', '2022-11-24 21:10:24', 'apollo', '2022-11-24 21:10:24');
INSERT INTO `role` VALUES ('132', 'ReleaseNamespace+gateway+application-common-redis+DEV', '\0', 'apollo', '2022-11-24 21:10:24', 'apollo', '2022-11-24 21:10:24');
INSERT INTO `role` VALUES ('133', 'ModifyNamespace+common+application-common-elasticsearch', '\0', 'apollo', '2022-11-24 21:24:33', 'apollo', '2022-11-24 21:24:33');
INSERT INTO `role` VALUES ('134', 'ReleaseNamespace+common+application-common-elasticsearch', '\0', 'apollo', '2022-11-24 21:24:33', 'apollo', '2022-11-24 21:24:33');
INSERT INTO `role` VALUES ('135', 'ModifyNamespace+common+application-common-elasticsearch+DEV', '\0', 'apollo', '2022-11-24 21:24:33', 'apollo', '2022-11-24 21:24:33');
INSERT INTO `role` VALUES ('136', 'ReleaseNamespace+common+application-common-elasticsearch+DEV', '\0', 'apollo', '2022-11-24 21:24:33', 'apollo', '2022-11-24 21:24:33');
INSERT INTO `role` VALUES ('137', 'ModifyNamespace+elasticsearch+application-common-elasticsearch', '\0', 'apollo', '2022-11-24 21:26:19', 'apollo', '2022-11-24 21:26:19');
INSERT INTO `role` VALUES ('138', 'ReleaseNamespace+elasticsearch+application-common-elasticsearch', '\0', 'apollo', '2022-11-24 21:26:20', 'apollo', '2022-11-24 21:26:20');
INSERT INTO `role` VALUES ('139', 'ModifyNamespace+elasticsearch+application-common-elasticsearch+DEV', '\0', 'apollo', '2022-11-24 21:26:20', 'apollo', '2022-11-24 21:26:20');
INSERT INTO `role` VALUES ('140', 'ReleaseNamespace+elasticsearch+application-common-elasticsearch+DEV', '\0', 'apollo', '2022-11-24 21:26:20', 'apollo', '2022-11-24 21:26:20');

-- ----------------------------
-- Table structure for rolepermission
-- ----------------------------
DROP TABLE IF EXISTS `rolepermission`;
CREATE TABLE `rolepermission` (
  `Id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增Id',
  `RoleId` int(10) unsigned DEFAULT NULL COMMENT 'Role Id',
  `PermissionId` int(10) unsigned DEFAULT NULL COMMENT 'Permission Id',
  `IsDeleted` bit(1) NOT NULL DEFAULT b'0' COMMENT '1: deleted, 0: normal',
  `DataChange_CreatedBy` varchar(32) DEFAULT '' COMMENT '创建人邮箱前缀',
  `DataChange_CreatedTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `DataChange_LastModifiedBy` varchar(32) DEFAULT '' COMMENT '最后修改人邮箱前缀',
  `DataChange_LastTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`Id`),
  KEY `IX_DataChange_LastTime` (`DataChange_LastTime`),
  KEY `IX_RoleId` (`RoleId`),
  KEY `IX_PermissionId` (`PermissionId`)
) ENGINE=InnoDB AUTO_INCREMENT=163 DEFAULT CHARSET=utf8mb4 COMMENT='角色和权限的绑定表';

-- ----------------------------
-- Records of rolepermission
-- ----------------------------
INSERT INTO `rolepermission` VALUES ('1', '1', '1', '', '', '2022-06-25 18:49:12', 'apollo', '2022-06-25 19:28:56');
INSERT INTO `rolepermission` VALUES ('2', '1', '2', '', '', '2022-06-25 18:49:12', 'apollo', '2022-06-25 19:28:56');
INSERT INTO `rolepermission` VALUES ('3', '1', '3', '', '', '2022-06-25 18:49:12', 'apollo', '2022-06-25 19:28:56');
INSERT INTO `rolepermission` VALUES ('4', '2', '4', '', '', '2022-06-25 18:49:12', 'apollo', '2022-06-25 19:28:56');
INSERT INTO `rolepermission` VALUES ('5', '3', '5', '', '', '2022-06-25 18:49:12', 'apollo', '2022-06-25 19:28:56');
INSERT INTO `rolepermission` VALUES ('6', '4', '6', '\0', 'apollo', '2022-06-25 18:51:06', 'apollo', '2022-06-25 18:51:06');
INSERT INTO `rolepermission` VALUES ('7', '5', '7', '\0', 'apollo', '2022-06-25 18:52:07', 'apollo', '2022-06-25 18:52:07');
INSERT INTO `rolepermission` VALUES ('8', '5', '8', '\0', 'apollo', '2022-06-25 18:52:07', 'apollo', '2022-06-25 18:52:07');
INSERT INTO `rolepermission` VALUES ('9', '5', '9', '\0', 'apollo', '2022-06-25 18:52:07', 'apollo', '2022-06-25 18:52:07');
INSERT INTO `rolepermission` VALUES ('10', '6', '10', '\0', 'apollo', '2022-06-25 18:52:07', 'apollo', '2022-06-25 18:52:07');
INSERT INTO `rolepermission` VALUES ('11', '7', '11', '\0', 'apollo', '2022-06-25 18:52:07', 'apollo', '2022-06-25 18:52:07');
INSERT INTO `rolepermission` VALUES ('12', '8', '12', '\0', 'apollo', '2022-06-25 18:52:07', 'apollo', '2022-06-25 18:52:07');
INSERT INTO `rolepermission` VALUES ('13', '9', '13', '\0', 'apollo', '2022-06-25 18:52:07', 'apollo', '2022-06-25 18:52:07');
INSERT INTO `rolepermission` VALUES ('14', '10', '14', '\0', 'apollo', '2022-06-25 18:52:07', 'apollo', '2022-06-25 18:52:07');
INSERT INTO `rolepermission` VALUES ('15', '11', '16', '\0', 'apollo', '2022-07-02 13:49:10', 'apollo', '2022-07-02 13:49:10');
INSERT INTO `rolepermission` VALUES ('16', '11', '17', '\0', 'apollo', '2022-07-02 13:49:10', 'apollo', '2022-07-02 13:49:10');
INSERT INTO `rolepermission` VALUES ('17', '11', '15', '\0', 'apollo', '2022-07-02 13:49:10', 'apollo', '2022-07-02 13:49:10');
INSERT INTO `rolepermission` VALUES ('18', '12', '18', '\0', 'apollo', '2022-07-02 13:49:10', 'apollo', '2022-07-02 13:49:10');
INSERT INTO `rolepermission` VALUES ('19', '13', '19', '\0', 'apollo', '2022-07-02 13:49:10', 'apollo', '2022-07-02 13:49:10');
INSERT INTO `rolepermission` VALUES ('20', '14', '20', '\0', 'apollo', '2022-07-02 13:49:10', 'apollo', '2022-07-02 13:49:10');
INSERT INTO `rolepermission` VALUES ('21', '15', '21', '\0', 'apollo', '2022-07-02 13:49:10', 'apollo', '2022-07-02 13:49:10');
INSERT INTO `rolepermission` VALUES ('22', '16', '22', '\0', 'apollo', '2022-07-02 13:49:10', 'apollo', '2022-07-02 13:49:10');
INSERT INTO `rolepermission` VALUES ('23', '17', '23', '', 'apollo', '2022-07-17 12:20:10', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `rolepermission` VALUES ('24', '17', '24', '', 'apollo', '2022-07-17 12:20:10', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `rolepermission` VALUES ('25', '17', '25', '', 'apollo', '2022-07-17 12:20:10', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `rolepermission` VALUES ('26', '18', '26', '', 'apollo', '2022-07-17 12:20:10', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `rolepermission` VALUES ('27', '19', '27', '', 'apollo', '2022-07-17 12:20:10', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `rolepermission` VALUES ('28', '20', '28', '', 'apollo', '2022-07-17 12:20:10', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `rolepermission` VALUES ('29', '21', '29', '', 'apollo', '2022-07-17 12:20:10', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `rolepermission` VALUES ('30', '22', '30', '', 'apollo', '2022-07-17 12:20:10', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `rolepermission` VALUES ('31', '23', '32', '', 'apollo', '2022-09-25 07:24:09', 'apollo', '2022-10-29 16:50:25');
INSERT INTO `rolepermission` VALUES ('32', '23', '33', '', 'apollo', '2022-09-25 07:24:09', 'apollo', '2022-10-29 16:50:25');
INSERT INTO `rolepermission` VALUES ('33', '23', '31', '', 'apollo', '2022-09-25 07:24:09', 'apollo', '2022-10-29 16:50:25');
INSERT INTO `rolepermission` VALUES ('34', '24', '34', '', 'apollo', '2022-09-25 07:24:09', 'apollo', '2022-10-29 16:50:25');
INSERT INTO `rolepermission` VALUES ('35', '25', '35', '', 'apollo', '2022-09-25 07:24:09', 'apollo', '2022-10-29 16:50:25');
INSERT INTO `rolepermission` VALUES ('36', '26', '36', '', 'apollo', '2022-09-25 07:24:09', 'apollo', '2022-10-29 16:50:25');
INSERT INTO `rolepermission` VALUES ('37', '27', '37', '', 'apollo', '2022-09-25 07:24:09', 'apollo', '2022-10-29 16:50:25');
INSERT INTO `rolepermission` VALUES ('38', '28', '38', '', 'apollo', '2022-09-25 07:24:09', 'apollo', '2022-10-29 16:50:25');
INSERT INTO `rolepermission` VALUES ('39', '29', '39', '\0', 'apollo', '2022-09-25 07:30:45', 'apollo', '2022-09-25 07:30:45');
INSERT INTO `rolepermission` VALUES ('40', '29', '40', '\0', 'apollo', '2022-09-25 07:30:45', 'apollo', '2022-09-25 07:30:45');
INSERT INTO `rolepermission` VALUES ('41', '29', '41', '\0', 'apollo', '2022-09-25 07:30:45', 'apollo', '2022-09-25 07:30:45');
INSERT INTO `rolepermission` VALUES ('42', '30', '42', '\0', 'apollo', '2022-09-25 07:30:45', 'apollo', '2022-09-25 07:30:45');
INSERT INTO `rolepermission` VALUES ('43', '31', '43', '\0', 'apollo', '2022-09-25 07:30:45', 'apollo', '2022-09-25 07:30:45');
INSERT INTO `rolepermission` VALUES ('44', '32', '44', '\0', 'apollo', '2022-09-25 07:30:45', 'apollo', '2022-09-25 07:30:45');
INSERT INTO `rolepermission` VALUES ('45', '33', '45', '\0', 'apollo', '2022-09-25 07:30:45', 'apollo', '2022-09-25 07:30:45');
INSERT INTO `rolepermission` VALUES ('46', '34', '46', '\0', 'apollo', '2022-09-25 07:30:45', 'apollo', '2022-09-25 07:30:45');
INSERT INTO `rolepermission` VALUES ('47', '35', '48', '', 'apollo', '2022-10-29 16:48:18', 'apollo', '2022-11-04 18:45:02');
INSERT INTO `rolepermission` VALUES ('48', '35', '49', '', 'apollo', '2022-10-29 16:48:18', 'apollo', '2022-11-04 18:45:02');
INSERT INTO `rolepermission` VALUES ('49', '35', '47', '', 'apollo', '2022-10-29 16:48:19', 'apollo', '2022-11-04 18:45:02');
INSERT INTO `rolepermission` VALUES ('50', '36', '50', '', 'apollo', '2022-10-29 16:48:19', 'apollo', '2022-11-04 18:45:02');
INSERT INTO `rolepermission` VALUES ('51', '37', '51', '', 'apollo', '2022-10-29 16:48:19', 'apollo', '2022-11-04 18:45:02');
INSERT INTO `rolepermission` VALUES ('52', '38', '52', '', 'apollo', '2022-10-29 16:48:19', 'apollo', '2022-11-04 18:45:02');
INSERT INTO `rolepermission` VALUES ('53', '39', '53', '', 'apollo', '2022-10-29 16:48:19', 'apollo', '2022-11-04 18:45:02');
INSERT INTO `rolepermission` VALUES ('54', '40', '54', '', 'apollo', '2022-10-29 16:48:19', 'apollo', '2022-11-04 18:45:02');
INSERT INTO `rolepermission` VALUES ('55', '41', '55', '', 'apollo', '2022-11-04 18:43:16', 'apollo', '2022-11-21 00:27:40');
INSERT INTO `rolepermission` VALUES ('56', '41', '56', '', 'apollo', '2022-11-04 18:43:16', 'apollo', '2022-11-21 00:27:40');
INSERT INTO `rolepermission` VALUES ('57', '41', '57', '', 'apollo', '2022-11-04 18:43:16', 'apollo', '2022-11-21 00:27:40');
INSERT INTO `rolepermission` VALUES ('58', '42', '58', '', 'apollo', '2022-11-04 18:43:16', 'apollo', '2022-11-21 00:27:40');
INSERT INTO `rolepermission` VALUES ('59', '43', '59', '', 'apollo', '2022-11-04 18:43:16', 'apollo', '2022-11-21 00:27:40');
INSERT INTO `rolepermission` VALUES ('60', '44', '60', '', 'apollo', '2022-11-04 18:43:16', 'apollo', '2022-11-21 00:27:40');
INSERT INTO `rolepermission` VALUES ('61', '45', '61', '', 'apollo', '2022-11-04 18:43:16', 'apollo', '2022-11-21 00:27:40');
INSERT INTO `rolepermission` VALUES ('62', '46', '62', '', 'apollo', '2022-11-04 18:43:16', 'apollo', '2022-11-21 00:27:40');
INSERT INTO `rolepermission` VALUES ('63', '47', '63', '', 'apollo', '2022-11-24 18:37:03', 'apollo', '2022-11-24 19:00:48');
INSERT INTO `rolepermission` VALUES ('64', '48', '64', '', 'apollo', '2022-11-24 18:37:03', 'apollo', '2022-11-24 19:00:48');
INSERT INTO `rolepermission` VALUES ('65', '49', '65', '', 'apollo', '2022-11-24 18:37:03', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `rolepermission` VALUES ('66', '50', '66', '', 'apollo', '2022-11-24 18:37:03', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `rolepermission` VALUES ('67', '51', '67', '', 'apollo', '2022-11-24 18:39:50', 'apollo', '2022-11-24 19:00:40');
INSERT INTO `rolepermission` VALUES ('68', '52', '68', '', 'apollo', '2022-11-24 18:39:50', 'apollo', '2022-11-24 19:00:40');
INSERT INTO `rolepermission` VALUES ('69', '53', '69', '', 'apollo', '2022-11-24 18:39:50', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `rolepermission` VALUES ('70', '54', '70', '', 'apollo', '2022-11-24 18:39:50', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `rolepermission` VALUES ('71', '55', '71', '\0', 'apollo', '2022-11-24 18:41:46', 'apollo', '2022-11-24 18:41:46');
INSERT INTO `rolepermission` VALUES ('72', '56', '72', '\0', 'apollo', '2022-11-24 18:41:46', 'apollo', '2022-11-24 18:41:46');
INSERT INTO `rolepermission` VALUES ('73', '57', '73', '\0', 'apollo', '2022-11-24 18:41:46', 'apollo', '2022-11-24 18:41:46');
INSERT INTO `rolepermission` VALUES ('74', '58', '74', '\0', 'apollo', '2022-11-24 18:41:46', 'apollo', '2022-11-24 18:41:46');
INSERT INTO `rolepermission` VALUES ('75', '59', '75', '\0', 'apollo', '2022-11-24 18:42:44', 'apollo', '2022-11-24 18:42:44');
INSERT INTO `rolepermission` VALUES ('76', '60', '76', '\0', 'apollo', '2022-11-24 18:42:44', 'apollo', '2022-11-24 18:42:44');
INSERT INTO `rolepermission` VALUES ('77', '61', '77', '\0', 'apollo', '2022-11-24 18:42:44', 'apollo', '2022-11-24 18:42:44');
INSERT INTO `rolepermission` VALUES ('78', '62', '78', '\0', 'apollo', '2022-11-24 18:42:44', 'apollo', '2022-11-24 18:42:44');
INSERT INTO `rolepermission` VALUES ('79', '63', '79', '\0', 'apollo', '2022-11-24 18:42:51', 'apollo', '2022-11-24 18:42:51');
INSERT INTO `rolepermission` VALUES ('80', '64', '80', '\0', 'apollo', '2022-11-24 18:42:51', 'apollo', '2022-11-24 18:42:51');
INSERT INTO `rolepermission` VALUES ('81', '65', '81', '\0', 'apollo', '2022-11-24 18:42:51', 'apollo', '2022-11-24 18:42:51');
INSERT INTO `rolepermission` VALUES ('82', '66', '82', '\0', 'apollo', '2022-11-24 18:42:51', 'apollo', '2022-11-24 18:42:51');
INSERT INTO `rolepermission` VALUES ('83', '67', '83', '', 'apollo', '2022-11-24 18:56:32', 'apollo', '2022-11-24 18:59:43');
INSERT INTO `rolepermission` VALUES ('84', '68', '84', '', 'apollo', '2022-11-24 18:56:32', 'apollo', '2022-11-24 18:59:43');
INSERT INTO `rolepermission` VALUES ('85', '69', '85', '', 'apollo', '2022-11-24 18:56:32', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `rolepermission` VALUES ('86', '70', '86', '', 'apollo', '2022-11-24 18:56:32', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `rolepermission` VALUES ('87', '71', '87', '', 'apollo', '2022-11-24 18:57:55', 'apollo', '2022-11-24 19:23:40');
INSERT INTO `rolepermission` VALUES ('88', '72', '88', '', 'apollo', '2022-11-24 18:57:56', 'apollo', '2022-11-24 19:23:40');
INSERT INTO `rolepermission` VALUES ('89', '73', '89', '', 'apollo', '2022-11-24 18:57:56', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `rolepermission` VALUES ('90', '74', '90', '', 'apollo', '2022-11-24 18:57:56', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `rolepermission` VALUES ('91', '75', '91', '', 'apollo', '2022-11-24 19:00:09', 'apollo', '2022-11-24 19:23:47');
INSERT INTO `rolepermission` VALUES ('92', '76', '92', '', 'apollo', '2022-11-24 19:00:09', 'apollo', '2022-11-24 19:23:47');
INSERT INTO `rolepermission` VALUES ('93', '77', '93', '', 'apollo', '2022-11-24 19:35:19', 'apollo', '2022-11-24 19:42:41');
INSERT INTO `rolepermission` VALUES ('94', '78', '94', '', 'apollo', '2022-11-24 19:35:19', 'apollo', '2022-11-24 19:42:41');
INSERT INTO `rolepermission` VALUES ('95', '79', '95', '', 'apollo', '2022-11-24 19:35:19', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `rolepermission` VALUES ('96', '80', '96', '', 'apollo', '2022-11-24 19:35:19', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `rolepermission` VALUES ('97', '81', '97', '', 'apollo', '2022-11-24 19:41:35', 'apollo', '2022-11-24 20:00:06');
INSERT INTO `rolepermission` VALUES ('98', '81', '98', '', 'apollo', '2022-11-24 19:41:35', 'apollo', '2022-11-24 20:00:06');
INSERT INTO `rolepermission` VALUES ('99', '81', '99', '', 'apollo', '2022-11-24 19:41:35', 'apollo', '2022-11-24 20:00:06');
INSERT INTO `rolepermission` VALUES ('100', '82', '100', '', 'apollo', '2022-11-24 19:41:35', 'apollo', '2022-11-24 20:00:06');
INSERT INTO `rolepermission` VALUES ('101', '83', '101', '', 'apollo', '2022-11-24 19:41:35', 'apollo', '2022-11-24 20:00:06');
INSERT INTO `rolepermission` VALUES ('102', '84', '102', '', 'apollo', '2022-11-24 19:41:35', 'apollo', '2022-11-24 20:00:06');
INSERT INTO `rolepermission` VALUES ('103', '85', '103', '', 'apollo', '2022-11-24 19:41:35', 'apollo', '2022-11-24 20:00:06');
INSERT INTO `rolepermission` VALUES ('104', '86', '104', '', 'apollo', '2022-11-24 19:41:35', 'apollo', '2022-11-24 20:00:06');
INSERT INTO `rolepermission` VALUES ('105', '87', '105', '', 'apollo', '2022-11-24 19:43:27', 'apollo', '2022-11-24 19:59:51');
INSERT INTO `rolepermission` VALUES ('106', '88', '106', '', 'apollo', '2022-11-24 19:43:27', 'apollo', '2022-11-24 19:59:51');
INSERT INTO `rolepermission` VALUES ('107', '89', '107', '', 'apollo', '2022-11-24 19:43:27', 'apollo', '2022-11-24 20:00:06');
INSERT INTO `rolepermission` VALUES ('108', '90', '108', '', 'apollo', '2022-11-24 19:43:27', 'apollo', '2022-11-24 20:00:06');
INSERT INTO `rolepermission` VALUES ('109', '91', '109', '', 'apollo', '2022-11-24 19:44:26', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `rolepermission` VALUES ('110', '92', '110', '', 'apollo', '2022-11-24 19:44:26', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `rolepermission` VALUES ('111', '93', '112', '\0', 'apollo', '2022-11-24 20:03:23', 'apollo', '2022-11-24 20:03:23');
INSERT INTO `rolepermission` VALUES ('112', '93', '113', '\0', 'apollo', '2022-11-24 20:03:23', 'apollo', '2022-11-24 20:03:23');
INSERT INTO `rolepermission` VALUES ('113', '93', '111', '\0', 'apollo', '2022-11-24 20:03:23', 'apollo', '2022-11-24 20:03:23');
INSERT INTO `rolepermission` VALUES ('114', '94', '114', '\0', 'apollo', '2022-11-24 20:03:23', 'apollo', '2022-11-24 20:03:23');
INSERT INTO `rolepermission` VALUES ('115', '95', '115', '\0', 'apollo', '2022-11-24 20:03:23', 'apollo', '2022-11-24 20:03:23');
INSERT INTO `rolepermission` VALUES ('116', '96', '116', '\0', 'apollo', '2022-11-24 20:03:23', 'apollo', '2022-11-24 20:03:23');
INSERT INTO `rolepermission` VALUES ('117', '97', '117', '\0', 'apollo', '2022-11-24 20:03:23', 'apollo', '2022-11-24 20:03:23');
INSERT INTO `rolepermission` VALUES ('118', '98', '118', '\0', 'apollo', '2022-11-24 20:03:23', 'apollo', '2022-11-24 20:03:23');
INSERT INTO `rolepermission` VALUES ('119', '99', '119', '\0', 'apollo', '2022-11-24 20:16:58', 'apollo', '2022-11-24 20:16:58');
INSERT INTO `rolepermission` VALUES ('120', '99', '120', '\0', 'apollo', '2022-11-24 20:16:58', 'apollo', '2022-11-24 20:16:58');
INSERT INTO `rolepermission` VALUES ('121', '99', '121', '\0', 'apollo', '2022-11-24 20:16:58', 'apollo', '2022-11-24 20:16:58');
INSERT INTO `rolepermission` VALUES ('122', '100', '122', '\0', 'apollo', '2022-11-24 20:16:58', 'apollo', '2022-11-24 20:16:58');
INSERT INTO `rolepermission` VALUES ('123', '101', '123', '\0', 'apollo', '2022-11-24 20:16:58', 'apollo', '2022-11-24 20:16:58');
INSERT INTO `rolepermission` VALUES ('124', '102', '124', '\0', 'apollo', '2022-11-24 20:16:58', 'apollo', '2022-11-24 20:16:58');
INSERT INTO `rolepermission` VALUES ('125', '103', '125', '\0', 'apollo', '2022-11-24 20:16:58', 'apollo', '2022-11-24 20:16:58');
INSERT INTO `rolepermission` VALUES ('126', '104', '126', '\0', 'apollo', '2022-11-24 20:16:58', 'apollo', '2022-11-24 20:16:58');
INSERT INTO `rolepermission` VALUES ('127', '105', '127', '\0', 'apollo', '2022-11-24 20:20:10', 'apollo', '2022-11-24 20:20:10');
INSERT INTO `rolepermission` VALUES ('128', '106', '128', '\0', 'apollo', '2022-11-24 20:20:10', 'apollo', '2022-11-24 20:20:10');
INSERT INTO `rolepermission` VALUES ('129', '107', '129', '\0', 'apollo', '2022-11-24 20:20:10', 'apollo', '2022-11-24 20:20:10');
INSERT INTO `rolepermission` VALUES ('130', '108', '130', '\0', 'apollo', '2022-11-24 20:20:10', 'apollo', '2022-11-24 20:20:10');
INSERT INTO `rolepermission` VALUES ('131', '109', '131', '\0', 'apollo', '2022-11-24 20:20:52', 'apollo', '2022-11-24 20:20:52');
INSERT INTO `rolepermission` VALUES ('132', '110', '132', '\0', 'apollo', '2022-11-24 20:20:52', 'apollo', '2022-11-24 20:20:52');
INSERT INTO `rolepermission` VALUES ('133', '111', '133', '\0', 'apollo', '2022-11-24 20:20:52', 'apollo', '2022-11-24 20:20:52');
INSERT INTO `rolepermission` VALUES ('134', '112', '134', '\0', 'apollo', '2022-11-24 20:20:52', 'apollo', '2022-11-24 20:20:52');
INSERT INTO `rolepermission` VALUES ('135', '113', '135', '\0', 'apollo', '2022-11-24 20:35:00', 'apollo', '2022-11-24 20:35:00');
INSERT INTO `rolepermission` VALUES ('136', '114', '136', '\0', 'apollo', '2022-11-24 20:35:00', 'apollo', '2022-11-24 20:35:00');
INSERT INTO `rolepermission` VALUES ('137', '115', '137', '\0', 'apollo', '2022-11-24 20:35:00', 'apollo', '2022-11-24 20:35:00');
INSERT INTO `rolepermission` VALUES ('138', '116', '138', '\0', 'apollo', '2022-11-24 20:35:00', 'apollo', '2022-11-24 20:35:00');
INSERT INTO `rolepermission` VALUES ('139', '117', '139', '', 'apollo', '2022-11-24 21:00:18', 'apollo', '2022-11-24 21:01:53');
INSERT INTO `rolepermission` VALUES ('140', '118', '140', '', 'apollo', '2022-11-24 21:00:18', 'apollo', '2022-11-24 21:01:53');
INSERT INTO `rolepermission` VALUES ('141', '119', '141', '\0', 'apollo', '2022-11-24 21:00:18', 'apollo', '2022-11-24 21:00:18');
INSERT INTO `rolepermission` VALUES ('142', '120', '142', '\0', 'apollo', '2022-11-24 21:00:18', 'apollo', '2022-11-24 21:00:18');
INSERT INTO `rolepermission` VALUES ('143', '121', '143', '\0', 'apollo', '2022-11-24 21:04:12', 'apollo', '2022-11-24 21:04:12');
INSERT INTO `rolepermission` VALUES ('144', '122', '144', '\0', 'apollo', '2022-11-24 21:04:12', 'apollo', '2022-11-24 21:04:12');
INSERT INTO `rolepermission` VALUES ('145', '123', '145', '\0', 'apollo', '2022-11-24 21:04:12', 'apollo', '2022-11-24 21:04:12');
INSERT INTO `rolepermission` VALUES ('146', '124', '146', '\0', 'apollo', '2022-11-24 21:04:12', 'apollo', '2022-11-24 21:04:12');
INSERT INTO `rolepermission` VALUES ('147', '125', '147', '\0', 'apollo', '2022-11-24 21:08:49', 'apollo', '2022-11-24 21:08:49');
INSERT INTO `rolepermission` VALUES ('148', '126', '148', '\0', 'apollo', '2022-11-24 21:08:49', 'apollo', '2022-11-24 21:08:49');
INSERT INTO `rolepermission` VALUES ('149', '127', '149', '\0', 'apollo', '2022-11-24 21:08:49', 'apollo', '2022-11-24 21:08:49');
INSERT INTO `rolepermission` VALUES ('150', '128', '150', '\0', 'apollo', '2022-11-24 21:08:49', 'apollo', '2022-11-24 21:08:49');
INSERT INTO `rolepermission` VALUES ('151', '129', '151', '\0', 'apollo', '2022-11-24 21:10:24', 'apollo', '2022-11-24 21:10:24');
INSERT INTO `rolepermission` VALUES ('152', '130', '152', '\0', 'apollo', '2022-11-24 21:10:24', 'apollo', '2022-11-24 21:10:24');
INSERT INTO `rolepermission` VALUES ('153', '131', '153', '\0', 'apollo', '2022-11-24 21:10:24', 'apollo', '2022-11-24 21:10:24');
INSERT INTO `rolepermission` VALUES ('154', '132', '154', '\0', 'apollo', '2022-11-24 21:10:24', 'apollo', '2022-11-24 21:10:24');
INSERT INTO `rolepermission` VALUES ('155', '133', '155', '\0', 'apollo', '2022-11-24 21:24:33', 'apollo', '2022-11-24 21:24:33');
INSERT INTO `rolepermission` VALUES ('156', '134', '156', '\0', 'apollo', '2022-11-24 21:24:33', 'apollo', '2022-11-24 21:24:33');
INSERT INTO `rolepermission` VALUES ('157', '135', '157', '\0', 'apollo', '2022-11-24 21:24:33', 'apollo', '2022-11-24 21:24:33');
INSERT INTO `rolepermission` VALUES ('158', '136', '158', '\0', 'apollo', '2022-11-24 21:24:33', 'apollo', '2022-11-24 21:24:33');
INSERT INTO `rolepermission` VALUES ('159', '137', '159', '\0', 'apollo', '2022-11-24 21:26:19', 'apollo', '2022-11-24 21:26:19');
INSERT INTO `rolepermission` VALUES ('160', '138', '160', '\0', 'apollo', '2022-11-24 21:26:20', 'apollo', '2022-11-24 21:26:20');
INSERT INTO `rolepermission` VALUES ('161', '139', '161', '\0', 'apollo', '2022-11-24 21:26:20', 'apollo', '2022-11-24 21:26:20');
INSERT INTO `rolepermission` VALUES ('162', '140', '162', '\0', 'apollo', '2022-11-24 21:26:20', 'apollo', '2022-11-24 21:26:20');

-- ----------------------------
-- Table structure for serverconfig
-- ----------------------------
DROP TABLE IF EXISTS `serverconfig`;
CREATE TABLE `serverconfig` (
  `Id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增Id',
  `Key` varchar(64) NOT NULL DEFAULT 'default' COMMENT '配置项Key',
  `Value` varchar(2048) NOT NULL DEFAULT 'default' COMMENT '配置项值',
  `Comment` varchar(1024) DEFAULT '' COMMENT '注释',
  `IsDeleted` bit(1) NOT NULL DEFAULT b'0' COMMENT '1: deleted, 0: normal',
  `DataChange_CreatedBy` varchar(32) NOT NULL DEFAULT 'default' COMMENT '创建人邮箱前缀',
  `DataChange_CreatedTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `DataChange_LastModifiedBy` varchar(32) DEFAULT '' COMMENT '最后修改人邮箱前缀',
  `DataChange_LastTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`Id`),
  KEY `IX_Key` (`Key`),
  KEY `DataChange_LastTime` (`DataChange_LastTime`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COMMENT='配置服务自身配置';

-- ----------------------------
-- Records of serverconfig
-- ----------------------------
INSERT INTO `serverconfig` VALUES ('1', 'apollo.portal.envs', 'dev', '可支持的环境列表', '\0', 'default', '2022-06-25 18:49:11', '', '2022-06-25 18:49:11');
INSERT INTO `serverconfig` VALUES ('2', 'organizations', '[{\"orgId\":\"TEST1\",\"orgName\":\"样例部门1\"},{\"orgId\":\"TEST2\",\"orgName\":\"样例部门2\"}]', '部门列表', '\0', 'default', '2022-06-25 18:49:11', '', '2022-06-25 18:49:11');
INSERT INTO `serverconfig` VALUES ('3', 'superAdmin', 'apollo', 'Portal超级管理员', '\0', 'default', '2022-06-25 18:49:11', '', '2022-06-25 18:49:11');
INSERT INTO `serverconfig` VALUES ('4', 'api.readTimeout', '10000', 'http接口read timeout', '\0', 'default', '2022-06-25 18:49:11', '', '2022-06-25 18:49:11');
INSERT INTO `serverconfig` VALUES ('5', 'consumer.token.salt', 'someSalt', 'consumer token salt', '\0', 'default', '2022-06-25 18:49:11', '', '2022-06-25 18:49:11');
INSERT INTO `serverconfig` VALUES ('6', 'admin.createPrivateNamespace.switch', 'true', '是否允许项目管理员创建私有namespace', '\0', 'default', '2022-06-25 18:49:11', '', '2022-06-25 18:49:11');
INSERT INTO `serverconfig` VALUES ('7', 'configView.memberOnly.envs', 'dev', '只对项目成员显示配置信息的环境列表，多个env以英文逗号分隔', '\0', 'default', '2022-06-25 18:49:11', '', '2022-06-25 18:49:11');

-- ----------------------------
-- Table structure for userrole
-- ----------------------------
DROP TABLE IF EXISTS `userrole`;
CREATE TABLE `userrole` (
  `Id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增Id',
  `UserId` varchar(128) DEFAULT '' COMMENT '用户身份标识',
  `RoleId` int(10) unsigned DEFAULT NULL COMMENT 'Role Id',
  `IsDeleted` bit(1) NOT NULL DEFAULT b'0' COMMENT '1: deleted, 0: normal',
  `DataChange_CreatedBy` varchar(32) DEFAULT '' COMMENT '创建人邮箱前缀',
  `DataChange_CreatedTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `DataChange_LastModifiedBy` varchar(32) DEFAULT '' COMMENT '最后修改人邮箱前缀',
  `DataChange_LastTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`Id`),
  KEY `IX_DataChange_LastTime` (`DataChange_LastTime`),
  KEY `IX_RoleId` (`RoleId`),
  KEY `IX_UserId_RoleId` (`UserId`,`RoleId`)
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8mb4 COMMENT='用户和role的绑定表';

-- ----------------------------
-- Records of userrole
-- ----------------------------
INSERT INTO `userrole` VALUES ('1', 'apollo', '1', '', '', '2022-06-25 18:49:12', 'apollo', '2022-06-25 19:28:56');
INSERT INTO `userrole` VALUES ('2', 'apollo', '2', '', '', '2022-06-25 18:49:12', 'apollo', '2022-06-25 19:28:56');
INSERT INTO `userrole` VALUES ('3', 'apollo', '3', '', '', '2022-06-25 18:49:12', 'apollo', '2022-06-25 19:28:56');
INSERT INTO `userrole` VALUES ('4', 'apollo', '5', '\0', 'apollo', '2022-06-25 18:52:07', 'apollo', '2022-06-25 18:52:07');
INSERT INTO `userrole` VALUES ('5', 'apollo', '7', '\0', 'apollo', '2022-06-25 18:52:07', 'apollo', '2022-06-25 18:52:07');
INSERT INTO `userrole` VALUES ('6', 'apollo', '8', '\0', 'apollo', '2022-06-25 18:52:07', 'apollo', '2022-06-25 18:52:07');
INSERT INTO `userrole` VALUES ('7', 'root', '4', '\0', 'apollo', '2022-06-25 18:55:18', 'apollo', '2022-06-25 18:55:18');
INSERT INTO `userrole` VALUES ('8', 'root', '6', '\0', 'apollo', '2022-06-25 18:55:54', 'apollo', '2022-06-25 18:55:54');
INSERT INTO `userrole` VALUES ('9', 'apollo', '4', '\0', 'apollo', '2022-06-25 18:56:50', 'apollo', '2022-06-25 18:56:50');
INSERT INTO `userrole` VALUES ('10', 'apollo', '11', '\0', 'apollo', '2022-07-02 13:49:10', 'apollo', '2022-07-02 13:49:10');
INSERT INTO `userrole` VALUES ('11', 'apollo', '13', '\0', 'apollo', '2022-07-02 13:49:10', 'apollo', '2022-07-02 13:49:10');
INSERT INTO `userrole` VALUES ('12', 'apollo', '14', '\0', 'apollo', '2022-07-02 13:49:10', 'apollo', '2022-07-02 13:49:10');
INSERT INTO `userrole` VALUES ('13', 'apollo', '17', '', 'apollo', '2022-07-17 12:20:10', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `userrole` VALUES ('14', 'apollo', '19', '', 'apollo', '2022-07-17 12:20:10', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `userrole` VALUES ('15', 'apollo', '20', '', 'apollo', '2022-07-17 12:20:10', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `userrole` VALUES ('16', 'apollo', '23', '', 'apollo', '2022-09-25 07:24:09', 'apollo', '2022-10-29 16:50:25');
INSERT INTO `userrole` VALUES ('17', 'apollo', '25', '', 'apollo', '2022-09-25 07:24:09', 'apollo', '2022-10-29 16:50:25');
INSERT INTO `userrole` VALUES ('18', 'apollo', '26', '', 'apollo', '2022-09-25 07:24:09', 'apollo', '2022-10-29 16:50:25');
INSERT INTO `userrole` VALUES ('19', 'apollo', '29', '\0', 'apollo', '2022-09-25 07:30:45', 'apollo', '2022-09-25 07:30:45');
INSERT INTO `userrole` VALUES ('20', 'apollo', '31', '\0', 'apollo', '2022-09-25 07:30:45', 'apollo', '2022-09-25 07:30:45');
INSERT INTO `userrole` VALUES ('21', 'apollo', '32', '\0', 'apollo', '2022-09-25 07:30:45', 'apollo', '2022-09-25 07:30:45');
INSERT INTO `userrole` VALUES ('22', 'apollo', '35', '', 'apollo', '2022-10-29 16:48:19', 'apollo', '2022-11-04 18:45:02');
INSERT INTO `userrole` VALUES ('23', 'apollo', '37', '', 'apollo', '2022-10-29 16:48:19', 'apollo', '2022-11-04 18:45:02');
INSERT INTO `userrole` VALUES ('24', 'apollo', '38', '', 'apollo', '2022-10-29 16:48:19', 'apollo', '2022-11-04 18:45:02');
INSERT INTO `userrole` VALUES ('25', 'apollo', '41', '', 'apollo', '2022-11-04 18:43:16', 'apollo', '2022-11-21 00:27:40');
INSERT INTO `userrole` VALUES ('26', 'apollo', '43', '', 'apollo', '2022-11-04 18:43:16', 'apollo', '2022-11-21 00:27:40');
INSERT INTO `userrole` VALUES ('27', 'apollo', '44', '', 'apollo', '2022-11-04 18:43:16', 'apollo', '2022-11-21 00:27:40');
INSERT INTO `userrole` VALUES ('28', 'apollo', '47', '', 'apollo', '2022-11-24 18:37:03', 'apollo', '2022-11-24 19:00:48');
INSERT INTO `userrole` VALUES ('29', 'apollo', '48', '', 'apollo', '2022-11-24 18:37:03', 'apollo', '2022-11-24 19:00:48');
INSERT INTO `userrole` VALUES ('30', 'apollo', '51', '', 'apollo', '2022-11-24 18:39:50', 'apollo', '2022-11-24 19:00:40');
INSERT INTO `userrole` VALUES ('31', 'apollo', '52', '', 'apollo', '2022-11-24 18:39:50', 'apollo', '2022-11-24 19:00:40');
INSERT INTO `userrole` VALUES ('32', 'apollo', '55', '\0', 'apollo', '2022-11-24 18:41:46', 'apollo', '2022-11-24 18:41:46');
INSERT INTO `userrole` VALUES ('33', 'apollo', '56', '\0', 'apollo', '2022-11-24 18:41:46', 'apollo', '2022-11-24 18:41:46');
INSERT INTO `userrole` VALUES ('34', 'apollo', '59', '\0', 'apollo', '2022-11-24 18:42:44', 'apollo', '2022-11-24 18:42:44');
INSERT INTO `userrole` VALUES ('35', 'apollo', '60', '\0', 'apollo', '2022-11-24 18:42:44', 'apollo', '2022-11-24 18:42:44');
INSERT INTO `userrole` VALUES ('36', 'apollo', '63', '\0', 'apollo', '2022-11-24 18:42:51', 'apollo', '2022-11-24 18:42:51');
INSERT INTO `userrole` VALUES ('37', 'apollo', '64', '\0', 'apollo', '2022-11-24 18:42:51', 'apollo', '2022-11-24 18:42:51');
INSERT INTO `userrole` VALUES ('38', 'apollo', '67', '', 'apollo', '2022-11-24 18:56:32', 'apollo', '2022-11-24 18:59:43');
INSERT INTO `userrole` VALUES ('39', 'apollo', '68', '', 'apollo', '2022-11-24 18:56:32', 'apollo', '2022-11-24 18:59:43');
INSERT INTO `userrole` VALUES ('40', 'apollo', '71', '', 'apollo', '2022-11-24 18:57:56', 'apollo', '2022-11-24 19:23:40');
INSERT INTO `userrole` VALUES ('41', 'apollo', '72', '', 'apollo', '2022-11-24 18:57:56', 'apollo', '2022-11-24 19:23:40');
INSERT INTO `userrole` VALUES ('42', 'apollo', '75', '', 'apollo', '2022-11-24 19:00:09', 'apollo', '2022-11-24 19:23:47');
INSERT INTO `userrole` VALUES ('43', 'apollo', '76', '', 'apollo', '2022-11-24 19:00:09', 'apollo', '2022-11-24 19:23:47');
INSERT INTO `userrole` VALUES ('44', 'apollo', '77', '', 'apollo', '2022-11-24 19:35:19', 'apollo', '2022-11-24 19:42:41');
INSERT INTO `userrole` VALUES ('45', 'apollo', '78', '', 'apollo', '2022-11-24 19:35:19', 'apollo', '2022-11-24 19:42:41');
INSERT INTO `userrole` VALUES ('46', 'apollo', '80', '', 'apollo', '2022-11-24 19:39:00', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `userrole` VALUES ('47', 'apollo', '79', '', 'apollo', '2022-11-24 19:39:07', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `userrole` VALUES ('48', 'apollo', '81', '', 'apollo', '2022-11-24 19:41:35', 'apollo', '2022-11-24 20:00:06');
INSERT INTO `userrole` VALUES ('49', 'apollo', '83', '', 'apollo', '2022-11-24 19:41:35', 'apollo', '2022-11-24 20:00:06');
INSERT INTO `userrole` VALUES ('50', 'apollo', '84', '', 'apollo', '2022-11-24 19:41:35', 'apollo', '2022-11-24 20:00:06');
INSERT INTO `userrole` VALUES ('51', 'apollo', '87', '', 'apollo', '2022-11-24 19:43:27', 'apollo', '2022-11-24 19:59:51');
INSERT INTO `userrole` VALUES ('52', 'apollo', '88', '', 'apollo', '2022-11-24 19:43:27', 'apollo', '2022-11-24 19:59:51');
INSERT INTO `userrole` VALUES ('53', 'apollo', '89', '', 'apollo', '2022-11-24 19:43:36', 'apollo', '2022-11-24 20:00:06');
INSERT INTO `userrole` VALUES ('54', 'apollo', '90', '', 'apollo', '2022-11-24 19:43:43', 'apollo', '2022-11-24 20:00:06');
INSERT INTO `userrole` VALUES ('55', 'apollo', '91', '', 'apollo', '2022-11-24 19:44:26', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `userrole` VALUES ('56', 'apollo', '92', '', 'apollo', '2022-11-24 19:44:27', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `userrole` VALUES ('57', 'apollo', '69', '', 'apollo', '2022-11-24 19:44:35', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `userrole` VALUES ('58', 'apollo', '70', '', 'apollo', '2022-11-24 19:44:41', 'apollo', '2022-11-24 20:03:02');
INSERT INTO `userrole` VALUES ('59', 'apollo', '93', '\0', 'apollo', '2022-11-24 20:03:23', 'apollo', '2022-11-24 20:03:23');
INSERT INTO `userrole` VALUES ('60', 'apollo', '95', '\0', 'apollo', '2022-11-24 20:03:23', 'apollo', '2022-11-24 20:03:23');
INSERT INTO `userrole` VALUES ('61', 'apollo', '96', '\0', 'apollo', '2022-11-24 20:03:23', 'apollo', '2022-11-24 20:03:23');
INSERT INTO `userrole` VALUES ('62', 'apollo', '99', '\0', 'apollo', '2022-11-24 20:16:58', 'apollo', '2022-11-24 20:16:58');
INSERT INTO `userrole` VALUES ('63', 'apollo', '101', '\0', 'apollo', '2022-11-24 20:16:58', 'apollo', '2022-11-24 20:16:58');
INSERT INTO `userrole` VALUES ('64', 'apollo', '102', '\0', 'apollo', '2022-11-24 20:16:58', 'apollo', '2022-11-24 20:16:58');
INSERT INTO `userrole` VALUES ('65', 'apollo', '105', '\0', 'apollo', '2022-11-24 20:20:10', 'apollo', '2022-11-24 20:20:10');
INSERT INTO `userrole` VALUES ('66', 'apollo', '106', '\0', 'apollo', '2022-11-24 20:20:10', 'apollo', '2022-11-24 20:20:10');
INSERT INTO `userrole` VALUES ('67', 'apollo', '109', '\0', 'apollo', '2022-11-24 20:20:52', 'apollo', '2022-11-24 20:20:52');
INSERT INTO `userrole` VALUES ('68', 'apollo', '110', '\0', 'apollo', '2022-11-24 20:20:52', 'apollo', '2022-11-24 20:20:52');
INSERT INTO `userrole` VALUES ('69', 'apollo', '113', '\0', 'apollo', '2022-11-24 20:35:00', 'apollo', '2022-11-24 20:35:00');
INSERT INTO `userrole` VALUES ('70', 'apollo', '114', '\0', 'apollo', '2022-11-24 20:35:00', 'apollo', '2022-11-24 20:35:00');
INSERT INTO `userrole` VALUES ('71', 'apollo', '117', '', 'apollo', '2022-11-24 21:00:18', 'apollo', '2022-11-24 21:01:53');
INSERT INTO `userrole` VALUES ('72', 'apollo', '118', '', 'apollo', '2022-11-24 21:00:18', 'apollo', '2022-11-24 21:01:53');
INSERT INTO `userrole` VALUES ('73', 'apollo', '121', '\0', 'apollo', '2022-11-24 21:04:12', 'apollo', '2022-11-24 21:04:12');
INSERT INTO `userrole` VALUES ('74', 'apollo', '122', '\0', 'apollo', '2022-11-24 21:04:12', 'apollo', '2022-11-24 21:04:12');
INSERT INTO `userrole` VALUES ('75', 'apollo', '125', '\0', 'apollo', '2022-11-24 21:08:49', 'apollo', '2022-11-24 21:08:49');
INSERT INTO `userrole` VALUES ('76', 'apollo', '126', '\0', 'apollo', '2022-11-24 21:08:49', 'apollo', '2022-11-24 21:08:49');
INSERT INTO `userrole` VALUES ('77', 'apollo', '129', '\0', 'apollo', '2022-11-24 21:10:24', 'apollo', '2022-11-24 21:10:24');
INSERT INTO `userrole` VALUES ('78', 'apollo', '130', '\0', 'apollo', '2022-11-24 21:10:24', 'apollo', '2022-11-24 21:10:24');
INSERT INTO `userrole` VALUES ('79', 'apollo', '133', '\0', 'apollo', '2022-11-24 21:24:34', 'apollo', '2022-11-24 21:24:34');
INSERT INTO `userrole` VALUES ('80', 'apollo', '134', '\0', 'apollo', '2022-11-24 21:24:34', 'apollo', '2022-11-24 21:24:34');
INSERT INTO `userrole` VALUES ('81', 'apollo', '137', '\0', 'apollo', '2022-11-24 21:26:20', 'apollo', '2022-11-24 21:26:20');
INSERT INTO `userrole` VALUES ('82', 'apollo', '138', '\0', 'apollo', '2022-11-24 21:26:20', 'apollo', '2022-11-24 21:26:20');

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `Id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增Id',
  `Username` varchar(64) NOT NULL DEFAULT 'default' COMMENT '用户名',
  `Password` varchar(64) NOT NULL DEFAULT 'default' COMMENT '密码',
  `Email` varchar(64) NOT NULL DEFAULT 'default' COMMENT '邮箱地址',
  `Enabled` tinyint(4) DEFAULT NULL COMMENT '是否有效',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES ('1', 'apollo', '$2a$10$n9qkc8bStC6UsJG1f7yk/uQcUFSr2w5E2laSMtxAtT1c4jV6GCjVW', 'apollo@acme.com', '1');
